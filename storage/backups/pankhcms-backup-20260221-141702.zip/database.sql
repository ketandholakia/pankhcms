-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: 127.0.0.1    Database: pankhcms
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  UNIQUE KEY `idx_categories_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_type_fields`
--

DROP TABLE IF EXISTS `content_type_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_type_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_type_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `label` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'text',
  `options` text DEFAULT NULL,
  `required` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `content_type_id` (`content_type_id`),
  CONSTRAINT `content_type_fields_ibfk_1` FOREIGN KEY (`content_type_id`) REFERENCES `content_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_type_fields`
--

LOCK TABLES `content_type_fields` WRITE;
/*!40000 ALTER TABLE `content_type_fields` DISABLE KEYS */;
INSERT INTO `content_type_fields` VALUES
(1,3,'productdetail','Product Details','text',NULL,0,0,'2026-02-21 04:10:06','2026-02-21 04:10:06');
/*!40000 ALTER TABLE `content_type_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_types`
--

DROP TABLE IF EXISTS `content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `has_categories` int(11) NOT NULL DEFAULT 1,
  `has_tags` int(11) NOT NULL DEFAULT 1,
  `is_system` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_types`
--

LOCK TABLES `content_types` WRITE;
/*!40000 ALTER TABLE `content_types` DISABLE KEYS */;
INSERT INTO `content_types` VALUES
(1,'Page','page','Standard website page','file',1,1,1,'2026-02-19 18:11:44','2026-02-19 18:11:44'),
(2,'Feature','feature','Product or service feature','star',1,1,0,'2026-02-19 18:11:44','2026-02-19 18:11:44'),
(3,'Product','product','Sellable product','shopping-cart',0,0,0,'2026-02-19 18:11:44','2026-02-21 04:10:14');
/*!40000 ALTER TABLE `content_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logs_user_id_foreign` (`user_id`),
  CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES
(5,'6999361215648_dehydrated-alfalfa-leaves-powder.jpg','dehydrated-alfalfa-leaves-powder.jpg','image/jpeg',381130,'/uploads/media/6999361215648_dehydrated-alfalfa-leaves-powder.jpg',NULL,NULL,NULL,NULL,'2026-02-21 04:35:30','2026-02-21 04:35:30');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_foreign` (`menu_id`),
  KEY `menu_items_page_id_foreign` (`page_id`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_items_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES
(1,1,NULL,'Home','/home',1,0),
(2,1,NULL,'About','/about',2,1),
(3,1,NULL,'Services','/services',3,2),
(4,1,NULL,'Products','/products',6,3),
(5,1,NULL,'Projects','/projects',5,4),
(7,1,NULL,'Contact','/contact',7,5);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,'Main Menu','header',0);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_categories`
--

DROP TABLE IF EXISTS `page_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_categories` (
  `page_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`page_id`,`category_id`),
  KEY `page_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `page_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `page_categories_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_categories`
--

LOCK TABLES `page_categories` WRITE;
/*!40000 ALTER TABLE `page_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_tags`
--

DROP TABLE IF EXISTS `page_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_tags` (
  `page_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`page_id`,`tag_id`),
  KEY `page_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `page_tags_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `page_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_tags`
--

LOCK TABLES `page_tags` WRITE;
/*!40000 ALTER TABLE `page_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'page',
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `og_title` text DEFAULT NULL,
  `og_description` text DEFAULT NULL,
  `og_image` text DEFAULT NULL,
  `canonical_url` text DEFAULT NULL,
  `robots` varchar(255) DEFAULT NULL,
  `twitter_card` varchar(255) DEFAULT NULL,
  `twitter_site` varchar(255) DEFAULT NULL,
  `noindex` int(11) NOT NULL DEFAULT 0,
  `content_json` text DEFAULT NULL,
  `layout` varchar(255) NOT NULL DEFAULT 'default',
  `status` varchar(255) NOT NULL DEFAULT 'published',
  `featured_image` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`),
  UNIQUE KEY `idx_pages_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,NULL,'page','Home','home',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[{\"type\":\"banner_slider\",\"data\":{\"autoplay\":true,\"interval\":5000,\"slides\":[{\"image\":\"/uploads/slide1.jpg\",\"title\":\"Engineering Excellence\",\"subtitle\":\"Building the future\",\"button_text\":\"Our Services\",\"button_link\":\"/services\"},{\"image\":\"/uploads/slide2.jpg\",\"title\":\"Innovative Solutions\",\"subtitle\":\"Smart infrastructure\",\"button_text\":\"Contact Us\",\"button_link\":\"/contact\"}]}},{\"type\":\"hero_basic\",\"data\":{\"title\":\"Build Faster Websites\",\"subtitle\":\"Lightweight CMS for modern projects\",\"cta_text\":\"Get Started\",\"cta_link\":\"/contact\"}},{\"type\":\"features_grid\",\"data\":{\"title\":\"Our Strengths\",\"items\":[{\"title\":\"Quality\",\"text\":\"Built to last\"},{\"title\":\"Speed\",\"text\":\"Fast delivery\"},{\"title\":\"Expert Team\",\"text\":\"Top engineers\"}]}},{\"type\":\"gallery\",\"data\":{\"images\":[\"/media/g1.jpg\",\"/media/g2.jpg\",\"/media/g3.jpg\"]}},{\"type\":\"cta_box\",\"data\":{\"title\":\"Need a custom website?\",\"text\":\"Contact our team today.\",\"button_text\":\"Contact Us\",\"button_link\":\"/contact\"}},{\"type\":\"testimonials\",\"data\":{\"title\":\"What Clients Say\",\"items\":[{\"name\":\"John Smith\",\"text\":\"Outstanding service!\"}]}}]','default','published',NULL,'2026-02-19 18:20:13','2026-02-20 18:24:07'),
(2,NULL,'page','About','about',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[{\"type\":\"text\",\"html\":\"<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container\\\">\\n<div class=\\\"row align-items-center g-5\\\"><!-- Image -->\\n<div class=\\\"col-lg-6\\\"><img class=\\\"img-fluid rounded shadow\\\" src=\\\"https://via.placeholder.com/800x550\\\" alt=\\\"Organic Dehydrated Foods Manufacturing Facility\\\"></div>\\n<!-- Content -->\\n<div class=\\\"col-lg-6\\\">\\n<h2 class=\\\"fw-bold mb-3\\\">About Organic Dehydrated Foods Pvt. Ltd.</h2>\\n<p>Established in 2016, Organic Dehydrated Foods Pvt. Ltd. is a certified manufacturer of food supplements, herbal oil drops, organic dehydrated vegetables, and herbal powders.</p>\\n<p>Our proprietary dehydration technology preserves natural nutrients, flavor, and medicinal value while maintaining the highest standards of purity and safety.</p>\\n<ul class=\\\"list-unstyled\\\">\\n<li>✔ ISO 22000:2018 &amp; HACCP Certified</li>\\n<li>✔ US-FDA &amp; WHO-GMP Compliance</li>\\n<li>✔ 100% Natural Products</li>\\n</ul>\\n</div>\\n</div>\\n</div>\\n</section>\\n<section class=\\\"py-5\\\">\\n<div class=\\\"container\\\">\\n<div class=\\\"row align-items-center g-5\\\"><!-- Content -->\\n<div class=\\\"col-lg-6 order-lg-1 order-2\\\">\\n<h2 class=\\\"fw-bold mb-3\\\">Natural Wellness Solutions</h2>\\n<p>We combine traditional herbal knowledge with advanced processing techniques to produce safe, effective, and high-quality natural products for global markets.</p>\\n<ul>\\n<li>Food Supplements</li>\\n<li>Herbal Oil Drops</li>\\n<li>Organic Dehydrated Vegetables</li>\\n<li>Herbal Powders</li>\\n</ul>\\n</div>\\n<!-- Image -->\\n<div class=\\\"col-lg-6 order-lg-2 order-1\\\"><img class=\\\"img-fluid rounded shadow\\\" src=\\\"https://via.placeholder.com/800x550\\\" alt=\\\"Organic Herbal Products\\\"></div>\\n</div>\\n</div>\\n</section>\\n<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container text-center\\\">\\n<h2 class=\\\"fw-bold mb-4\\\">Quality &amp; Research</h2>\\n<p class=\\\"lead mx-auto\\\" style=\\\"max-width: 800px;\\\">Strict quality control measures are implemented at every stage of production. Our R&amp;D team continuously develops improved formulations to meet international standards and customer expectations.</p>\\n<img class=\\\"img-fluid rounded shadow mt-4\\\" src=\\\"https://via.placeholder.com/900x400\\\" alt=\\\"Quality Testing Laboratory\\\"></div>\\n</section>\\n<section class=\\\"py-5\\\">\\n<div class=\\\"container text-center\\\">\\n<h2 class=\\\"fw-bold mb-5\\\">Mission &amp; Vision</h2>\\n<div class=\\\"row g-4\\\">\\n<div class=\\\"col-md-6\\\">\\n<div class=\\\"card h-100 border-0 shadow\\\">\\n<div class=\\\"card-body\\\">\\n<h4 class=\\\"fw-bold\\\">Mission</h4>\\n<p>To deliver high-quality natural products globally while promoting health, sustainability, and ethical sourcing.</p>\\n</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-6\\\">\\n<div class=\\\"card h-100 border-0 shadow\\\">\\n<div class=\\\"card-body\\\">\\n<h4 class=\\\"fw-bold\\\">Vision</h4>\\n<p>To become a trusted global leader in natural wellness products with superior nutritional and medicinal value.</p>\\n</div>\\n</div>\\n</div>\\n</div>\\n</div>\\n</section>\"}]','default','published',NULL,'2026-02-19 18:20:31','2026-02-20 15:05:00'),
(3,NULL,'page','Services','services',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[]','default','published',NULL,'2026-02-19 18:20:50','2026-02-20 07:40:06'),
(4,NULL,'page','Portfolio','portfolio',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[]','default','published',NULL,'2026-02-19 18:21:07','2026-02-19 18:21:07'),
(5,NULL,'page','Projects','projects',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[]','default','published',NULL,'2026-02-19 18:21:34','2026-02-19 18:21:34'),
(6,NULL,'page','Products','products',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[]','default','published',NULL,'2026-02-19 18:21:52','2026-02-19 18:21:52'),
(7,NULL,'page','Contact','contact',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'[]','default','published',NULL,'2026-02-20 07:17:36','2026-02-20 07:17:36');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redirects`
--

DROP TABLE IF EXISTS `redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redirects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` text DEFAULT NULL,
  `new_url` text DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 301,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirects`
--

LOCK TABLES `redirects` WRITE;
/*!40000 ALTER TABLE `redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `role_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
('active_theme','greenbs'),
('admin_email',''),
('breadcrumbs_enabled','1'),
('breadcrumbs_home_label','Home'),
('breadcrumbs_schema','1'),
('breadcrumbs_separator','/'),
('breadcrumbs_show_home','1'),
('breadcrumbs_type','auto'),
('date_format','Y-m-d'),
('default_language','en'),
('homepage_id','1'),
('logo_path',''),
('posts_per_page','10'),
('site_name','Organic Dehydrated Foods Pvt. Ltd. '),
('site_tagline','Dehydrated Vegetable, Herbal and Fruit Products'),
('time_format','H:i'),
('timezone','UTC');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`),
  UNIQUE KEY `idx_tags_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `content_json` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES
(1,'Hero Block','[\r\n{\r\n  \"type\": \"hero_basic\",\r\n  \"data\": {\r\n    \"title\": \"Build Faster Websites\",\r\n    \"subtitle\": \"Lightweight CMS for modern projects\",\r\n    \"cta_text\": \"Get Started\",\r\n    \"cta_link\": \"/contact\"\r\n  }\r\n}\r\n]','2026-02-19 19:28:30'),
(2,'Content Block','[\r\n{\r\n  \"type\": \"text_content\",\r\n  \"data\": {\r\n    \"title\": \"About Our Company\",\r\n    \"text\": \"We deliver innovative engineering solutions worldwide.\"\r\n  }\r\n}\r\n]','2026-02-19 19:29:15'),
(3,'Rich Content Block ','[{\r\n  \"type\": \"rich_content\",\r\n  \"data\": {\r\n    \"html\": \"<p><strong>Custom HTML</strong> from editor</p>\"\r\n  }\r\n}\r\n]','2026-02-19 19:29:37'),
(4,'Feature / Service Block ','[{\r\n  \"type\": \"features_grid\",\r\n  \"data\": {\r\n    \"title\": \"Our Strengths\",\r\n    \"items\": [\r\n      { \"title\": \"Quality\", \"text\": \"Built to last\" },\r\n      { \"title\": \"Speed\", \"text\": \"Fast delivery\" },\r\n      { \"title\": \"Expert Team\", \"text\": \"Top engineers\" }\r\n    ]\r\n  }\r\n}\r\n]','2026-02-19 19:29:58'),
(5,'Media Block ','[{\r\n  \"type\": \"image\",\r\n  \"data\": {\r\n    \"src\": \"/media/project.jpg\",\r\n    \"alt\": \"Project image\",\r\n    \"caption\": \"Completed project\"\r\n  }\r\n}\r\n]','2026-02-19 19:30:20'),
(6,'Gallery Block','[{\r\n  \"type\": \"gallery\",\r\n  \"data\": {\r\n    \"images\": [\r\n      \"/media/g1.jpg\",\r\n      \"/media/g2.jpg\",\r\n      \"/media/g3.jpg\"\r\n    ]\r\n  }\r\n}\r\n]','2026-02-19 19:30:40'),
(7,'cta block','[{\r\n  \"type\": \"cta_box\",\r\n  \"data\": {\r\n    \"title\": \"Need a custom website?\",\r\n    \"text\": \"Contact our team today.\",\r\n    \"button_text\": \"Contact Us\",\r\n    \"button_link\": \"/contact\"\r\n  }\r\n}\r\n]','2026-02-19 19:31:03'),
(8,'testimonial Blcik','[{\r\n  \"type\": \"testimonials\",\r\n  \"data\": {\r\n    \"title\": \"What Clients Say\",\r\n    \"items\": [\r\n      {\r\n        \"name\": \"John Smith\",\r\n        \"text\": \"Outstanding service!\"\r\n      }\r\n    ]\r\n  }\r\n}\r\n\r\n]','2026-02-19 19:31:21'),
(9,'Team Block ','[{\r\n  \"type\": \"team_grid\",\r\n  \"data\": {\r\n    \"title\": \"Our Team\",\r\n    \"members\": [\r\n      {\r\n        \"name\": \"Jane Doe\",\r\n        \"role\": \"CEO\",\r\n        \"photo\": \"/media/jane.jpg\"\r\n      }\r\n    ]\r\n  }\r\n}\r\n]','2026-02-19 19:31:38'),
(10,'contact Block ','[{\r\n  \"type\": \"contact_info\",\r\n  \"data\": {\r\n    \"address\": \"Mumbai, India\",\r\n    \"phone\": \"+91 99999 99999\",\r\n    \"email\": \"info@example.com\"\r\n  }\r\n}\r\n]','2026-02-19 19:31:57'),
(11,'Two Column Layout Block','[{\r\n  \"type\": \"two_columns\",\r\n  \"data\": {\r\n    \"left\": \"HTML or nested blocks\",\r\n    \"right\": \"HTML or nested blocks\"\r\n  }\r\n}\r\n]','2026-02-19 19:32:22'),
(12,'Spacer Block','[{\r\n  \"type\": \"spacer\",\r\n  \"data\": {\r\n    \"height\": \"60px\"\r\n  }\r\n}\r\n]','2026-02-19 19:32:42'),
(13,'Slider Banner Block','[\r\n{\r\n  \"type\": \"banner_slider\",\r\n  \"data\": {\r\n    \"autoplay\": true,\r\n    \"interval\": 5000,\r\n    \"slides\": [\r\n      {\r\n        \"image\": \"/uploads/slide1.jpg\",\r\n        \"title\": \"Engineering Excellence\",\r\n        \"subtitle\": \"Building the future\",\r\n        \"button_text\": \"Our Services\",\r\n        \"button_link\": \"/services\"\r\n      },\r\n      {\r\n        \"image\": \"/uploads/slide2.jpg\",\r\n        \"title\": \"Innovative Solutions\",\r\n        \"subtitle\": \"Smart infrastructure\",\r\n        \"button_text\": \"Contact Us\",\r\n        \"button_link\": \"/contact\"\r\n      }\r\n    ]\r\n  }\r\n}\r\n]','2026-02-20 15:16:23');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_roles_role_id_foreign` (`role_id`),
  CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,'admin@gmail.com','$2y$10$BTmowwHxb5syad02aN3K5ORfqB.dC7SpwyOgA3w3KVCOzq4VrvBqu','2026-02-19 18:11:44','2026-02-19 18:11:44');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-21 14:17:02
