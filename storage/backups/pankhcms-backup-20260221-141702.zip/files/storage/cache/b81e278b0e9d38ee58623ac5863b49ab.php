<section class="py-4">
    <div class="container">
        <?php echo $block['html'] ?? ($block['data']['text'] ?? ''); ?>

    </div>
</section>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/text.blade.php ENDPATH**/ ?>