<section class="py-5 bg-primary text-white text-center">
    <div class="container">
        <h2><?php echo e($block['data']['title'] ?? ''); ?></h2>
        <p><?php echo e($block['data']['text'] ?? ''); ?></p>
        <?php if(!empty($block['data']['button_text'])): ?>
            <a href="<?php echo e($block['data']['button_link'] ?? '#'); ?>" class="btn btn-light"><?php echo e($block['data']['button_text']); ?></a>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/cta_box.blade.php ENDPATH**/ ?>