<?php use Illuminate\Support\Str; ?>


<?php $__env->startSection('content'); ?>
<div class="w-full p-6 bg-gray-50 rounded-xl shadow-sm border border-gray-200">
    <div id="media-notification" class="hidden mb-4 p-3 rounded text-white"></div>
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <h2 class="text-2xl font-bold text-gray-800">Media Library</h2>
        <form id="media-upload-form" action="/admin/media/upload" method="POST" enctype="multipart/form-data" class="flex items-center gap-2">
            <!-- Add CSRF token here if your framework requires it, otherwise remove. Example: -->
            <!-- <input type="hidden" name="_token" value="<?php echo e($_SESSION['csrf_token'] ?? ''); ?>"> -->
            <label class="cursor-pointer bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all flex items-center gap-2 shadow-sm mb-0">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
                <span>Upload New File</span>
                <input type="file" name="file" class="hidden" required />
            </label>
        </form>
    </div>

    <form id="media-search-form" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4 bg-white p-4 rounded-lg shadow-inner border border-gray-100 mb-6">
        <div class="relative">
            <input type="text" name="search" value="<?php echo e($search ?? ''); ?>" placeholder="Search files..." class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm" />
            <span class="absolute left-3 top-2.5 text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </span>
        </div>
        <select name="type" class="w-full px-3 py-2 border border-gray-300 rounded-md bg-white text-sm focus:outline-none">
            <option value="">All Types</option>
            <option value="image" <?php if(($type ?? '')=='image'): ?> selected <?php endif; ?>>Images</option>
            <option value="video" <?php if(($type ?? '')=='video'): ?> selected <?php endif; ?>>Videos</option>
            <option value="audio" <?php if(($type ?? '')=='audio'): ?> selected <?php endif; ?>>Audio</option>
            <option value="application" <?php if(($type ?? '')=='application'): ?> selected <?php endif; ?>>Documents</option>
        </select>
        <input type="date" name="date" value="<?php echo e($date ?? ''); ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none" />
        <button class="bg-gray-800 hover:bg-black text-white px-4 py-2 rounded-md text-sm font-medium transition-colors" type="submit">
            Apply Filters
        </button>
    </form>

    <div id="media-list" class="border-2 border-dashed border-gray-200 rounded-xl min-h-[16rem] flex items-center justify-center text-gray-400">
        <?php if(count($media) === 0): ?>
            <p>Your uploaded media will appear here</p>
        <?php else: ?>
            <div class="w-full grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 p-4">
                <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow p-2 flex flex-col items-center">
                        <?php if(Str::startsWith($item->mime_type, 'image/')): ?>
                            <img src="<?php echo e($item->url); ?>" class="w-full h-24 object-cover rounded mb-2" alt="<?php echo e($item->alt ?? $item->original_name); ?>">
                        <?php else: ?>
                            <div class="flex flex-col items-center justify-center h-24 w-full bg-gray-100 rounded mb-2">
                                <span class="text-xs text-gray-500"><?php echo e($item->mime_type); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="text-xs text-gray-700 truncate w-full text-center"><?php echo e($item->original_name); ?></div>
                        <button class="btn btn-sm btn-danger bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded text-xs media-delete-btn mt-2" data-id="<?php echo e($item->id); ?>">Delete</button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
        
    </div>
</div>
<script>
const uploadForm = document.getElementById('media-upload-form');
const fileInput = uploadForm.querySelector('input[type="file"]');

fileInput.addEventListener('change', function() {
    if (fileInput.files.length > 0) {
        // Trigger AJAX upload
        uploadForm.dispatchEvent(new Event('submit', {cancelable: true, bubbles: true}));
    }
});

uploadForm.addEventListener('submit', function(e) {
    e.preventDefault();
    var form = this;
    var data = new FormData(form);
    fetch(form.action, {
        method: 'POST',
        body: data
    })
    .then(res => res.json())
    .then(function(resp) {
        if (resp.success) {
            showMediaNotification('Upload successful!', 'success');
            setTimeout(() => window.location.reload(), 1200);
        } else {
            showMediaNotification(resp.error || 'Upload failed', 'error');
        }
    })
    .catch(function() {
        showMediaNotification('Upload failed', 'error');
    });
});

document.querySelectorAll('.media-delete-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        if (!confirm('Delete this file?')) return;
        var id = btn.getAttribute('data-id');
        fetch(`/admin/media/${id}/delete`, {
            method: 'POST'
        })
        .then(res => res.json())
        .then(function(resp) {
            if (resp.success) {
                showMediaNotification('File deleted!', 'success');
                setTimeout(() => window.location.reload(), 800);
            } else {
                showMediaNotification(resp.error || 'Delete failed', 'error');
            }
        })
        .catch(function() {
            showMediaNotification('Delete failed', 'error');
        });
    });
});

function showMediaNotification(message, type = 'info') {
    var notif = document.getElementById('media-notification');
    notif.textContent = message;
    notif.className = 'mb-4 p-3 rounded text-white';
    if (type === 'error') {
        notif.classList.add('bg-red-500');
    } else if (type === 'success') {
        notif.classList.add('bg-green-500');
    } else {
        notif.classList.add('bg-blue-500');
    }
    notif.classList.remove('hidden');
    setTimeout(() => notif.classList.add('hidden'), 4000);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/pankhCMS/views/admin/media/index.blade.php ENDPATH**/ ?>