<section class="py-5 text-center bg-light">
    <div class="container">
        <h1><?php echo e($block['data']['title'] ?? ''); ?></h1>
        <p class="lead"><?php echo e($block['data']['subtitle'] ?? ''); ?></p>
        <?php if(!empty($block['data']['cta_text'])): ?>
            <a href="<?php echo e($block['data']['cta_link'] ?? '#'); ?>" class="btn btn-primary"><?php echo e($block['data']['cta_text']); ?></a>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/hero_basic.blade.php ENDPATH**/ ?>