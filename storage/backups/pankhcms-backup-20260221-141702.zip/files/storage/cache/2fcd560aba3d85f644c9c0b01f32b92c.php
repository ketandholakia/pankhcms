<section class="py-4 bg-white">
    <div class="container">
        <h2><?php echo e($block['data']['title'] ?? ''); ?></h2>
        <div class="row">
            <?php $__currentLoopData = $block['data']['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <blockquote class="blockquote">
                        <p><?php echo e($item['text']); ?></p>
                        <footer class="blockquote-footer"><?php echo e($item['name']); ?></footer>
                    </blockquote>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/testimonials.blade.php ENDPATH**/ ?>