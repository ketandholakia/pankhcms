<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $type = $block['type'] ?? '';
            $partial = 'blocks.' . $type;
        ?>
        <?php if ($__env->exists($partial, ['block' => $block])) echo $__env->make($partial, ['block' => $block], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/page.blade.php ENDPATH**/ ?>