<?php $__env->startSection('content'); ?>
<h1>Dashboard</h1>
<p>Welcome to Mini CMS</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/pankhCMS/views/admin/dashboard.blade.php ENDPATH**/ ?>