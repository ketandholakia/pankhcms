<section class="py-4">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $block['data']['images'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <img src="<?php echo e($img); ?>" class="img-fluid rounded shadow-sm" alt="Gallery image">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/gallery.blade.php ENDPATH**/ ?>