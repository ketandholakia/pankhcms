<section class="py-4">
    <div class="container">
        <h2><?php echo e($block['data']['title'] ?? ''); ?></h2>
        <div class="row">
            <?php $__currentLoopData = $block['data']['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item['title']); ?></h5>
                            <p class="card-text"><?php echo e($item['text']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/features_grid.blade.php ENDPATH**/ ?>