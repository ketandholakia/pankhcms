<section class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                {!! $block['data']['left'] ?? '' !!}
            </div>
            <div class="col-md-6">
                {!! $block['data']['right'] ?? '' !!}
            </div>
        </div>
    </div>
</section>
