<div style="height: {{ $block['data']['height'] ?? '40px' }};"></div>
