<article class="content card">
  {!! $content !!}
</article>
