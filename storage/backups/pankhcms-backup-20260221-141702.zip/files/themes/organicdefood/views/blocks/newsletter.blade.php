<div>
    <h4>Newsletter</h4>
    <p class="mb-3">Subscribe for updates and offers.</p>
    <form method="POST" action="/contact" class="d-flex gap-2">
        <input type="email" name="email" class="form-control" placeholder="Your email" aria-label="Email">
        <button type="submit" class="btn btn-secondary">Subscribe</button>
    </form>
</div>
