<section class="py-5">
    <div class="container">
        <div class="p-4 p-md-5 rounded-3 bg-white border text-center shadow-sm">
            <h2 class="h3 mb-3">Build client sites faster</h2>
            <p class="text-muted mb-4">Switch between themes instantly while keeping your content unchanged.</p>
            <a href="/" class="btn btn-primary">Explore Site</a>
        </div>
    </div>
</section>
