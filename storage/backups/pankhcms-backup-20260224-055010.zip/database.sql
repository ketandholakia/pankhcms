
-- Table structure for `categories`
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  UNIQUE KEY `idx_categories_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `categories`
INSERT INTO `categories` VALUES('1','Food Supplement - Capsules','food-supplement-capsules',NULL);
INSERT INTO `categories` VALUES('2','Health Supplements - Syrup Form','health-suppleements-syrup-form',NULL);
INSERT INTO `categories` VALUES('3','Herbal Oil Drops','herbal-oil-drops',NULL);
INSERT INTO `categories` VALUES('4','Natural Food Supplement - Powder','natural-food-supplement-powder',NULL);
INSERT INTO `categories` VALUES('5','Organic Vegetables & Herbs Powder','organic-vegetables-herbs-powder',NULL);


-- Table structure for `contact_messages`
DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `contact_messages`
INSERT INTO `contact_messages` VALUES('1','Ketan','ketanmci@gmail.com','testing form','test message','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',NULL);


-- Table structure for `content_type_fields`
DROP TABLE IF EXISTS `content_type_fields`;
CREATE TABLE `content_type_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_type_id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `label` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'text',
  `options` text DEFAULT NULL,
  `required` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `content_type_id` (`content_type_id`),
  CONSTRAINT `content_type_fields_ibfk_1` FOREIGN KEY (`content_type_id`) REFERENCES `content_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `content_type_fields`
INSERT INTO `content_type_fields` VALUES('1','3','productdetail','Product Details','text',NULL,'0','0','2026-02-21 04:10:06','2026-02-21 04:10:06');
INSERT INTO `content_type_fields` VALUES('2','3','show_in_product_gallery','Show in Product Gallery','checkbox',NULL,'0','0','2026-02-22 04:06:58','2026-02-22 04:06:58');


-- Table structure for `content_types`
DROP TABLE IF EXISTS `content_types`;
CREATE TABLE `content_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `has_categories` int(11) NOT NULL DEFAULT 1,
  `has_tags` int(11) NOT NULL DEFAULT 1,
  `is_system` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_types_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `content_types`
INSERT INTO `content_types` VALUES('1','Page','page','Standard website page','file','1','1','1','2026-02-19 18:11:44','2026-02-19 18:11:44');
INSERT INTO `content_types` VALUES('2','Feature','feature','Product or service feature','star','1','1','0','2026-02-19 18:11:44','2026-02-19 18:11:44');
INSERT INTO `content_types` VALUES('3','Products','products','Sellable product','shopping-cart','1','0','0','2026-02-19 18:11:44','2026-02-22 18:22:48');
INSERT INTO `content_types` VALUES('4','Gallery','gallery',NULL,NULL,'0','0','0','2026-02-23 17:35:30','2026-02-23 17:35:30');


-- Table structure for `logs`
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logs_user_id_foreign` (`user_id`),
  CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `media`
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `media`
INSERT INTO `media` VALUES('5','6999361215648_dehydrated-alfalfa-leaves-powder.jpg','dehydrated-alfalfa-leaves-powder.jpg','image/jpeg','381130','/uploads/media/6999361215648_dehydrated-alfalfa-leaves-powder.jpg',NULL,NULL,NULL,NULL,'2026-02-21 04:35:30','2026-02-21 04:35:30');
INSERT INTO `media` VALUES('6','6999bf3f70a5a_ActiveHeartTonic_1.jpg','Active Heart Tonic_1.jpg','image/jpeg','965936','/uploads/media/6999bf3f70a5a_ActiveHeartTonic_1.jpg',NULL,NULL,NULL,NULL,'2026-02-21 14:20:47','2026-02-21 14:20:47');
INSERT INTO `media` VALUES('7','087791d72f313ecf60c32de8eba6e2a5.jpg','ISO 22000 2018 Certificate_0.jpg','image/jpeg','775051','/uploads/media/087791d72f313ecf60c32de8eba6e2a5.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:14:25','2026-02-22 17:14:25');
INSERT INTO `media` VALUES('8','4ade3c1bad79fee87c53672a9f8fd8ec.jpg','Organic Certificate_0.jpg','image/jpeg','824851','/uploads/media/4ade3c1bad79fee87c53672a9f8fd8ec.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:14:40','2026-02-22 17:14:40');
INSERT INTO `media` VALUES('9','1c3bccb1699fcfc5813034e223835b93.jpg','WHO-GMP Certificate_0.jpg','image/jpeg','853195','/uploads/media/1c3bccb1699fcfc5813034e223835b93.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:14:49','2026-02-22 17:14:49');
INSERT INTO `media` VALUES('10','4f09f6ac35fa97709dc2a3721674ef95.jpg','FSSAI License_0.jpg','image/jpeg','1086422','/uploads/media/4f09f6ac35fa97709dc2a3721674ef95.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:14:59','2026-02-22 17:14:59');
INSERT INTO `media` VALUES('11','a18e0009fd17e77e76a26adffbcae754.jpg','HACCP Certificate.jpg','image/jpeg','774746','/uploads/media/a18e0009fd17e77e76a26adffbcae754.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:15:09','2026-02-22 17:15:09');
INSERT INTO `media` VALUES('12','fd2a75a7bc4bf0baab5ee910cb46bf92.jpg','USFDA Certificate.jpg','image/jpeg','598824','/uploads/media/fd2a75a7bc4bf0baab5ee910cb46bf92.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:15:18','2026-02-22 17:15:18');
INSERT INTO `media` VALUES('13','60bb9c7efb19a34106d8d20622e88001.jpg','ISO 22000 2018 Certificate_0.jpg','image/jpeg','775051','/uploads/media/60bb9c7efb19a34106d8d20622e88001.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:29:46','2026-02-22 17:29:46');
INSERT INTO `media` VALUES('14','2476cd190e019d90467300a65744ddc1.jpg','Organic Certificate_0.jpg','image/jpeg','824851','/uploads/media/2476cd190e019d90467300a65744ddc1.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:30:56','2026-02-22 17:30:56');
INSERT INTO `media` VALUES('15','87a991ff1c41d18a37130a7e0379956a.jpg','WHO-GMP Certificate_0.jpg','image/jpeg','853195','/uploads/media/87a991ff1c41d18a37130a7e0379956a.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:31:36','2026-02-22 17:31:36');
INSERT INTO `media` VALUES('16','d8a7dd7667e6804e13218bac59a586e8.jpg','FSSAI License_0.jpg','image/jpeg','1086422','/uploads/media/d8a7dd7667e6804e13218bac59a586e8.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:32:21','2026-02-22 17:32:21');
INSERT INTO `media` VALUES('17','05221a7c26d9f41d659832360018494e.jpg','HACCP Certificate.jpg','image/jpeg','774746','/uploads/media/05221a7c26d9f41d659832360018494e.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:32:54','2026-02-22 17:32:54');
INSERT INTO `media` VALUES('18','149c6803068605283c78f5e0255bf7ea.jpg','USFDA Certificate.jpg','image/jpeg','598824','/uploads/media/149c6803068605283c78f5e0255bf7ea.jpg',NULL,NULL,NULL,NULL,'2026-02-22 17:33:24','2026-02-22 17:33:24');
INSERT INTO `media` VALUES('19','802eb8f12cd07e3bc9736d7889bd5cfa.jpg','Active Heart Tonic_1.jpg','image/jpeg','965936','/uploads/media/802eb8f12cd07e3bc9736d7889bd5cfa.jpg',NULL,NULL,NULL,NULL,'2026-02-23 18:23:22','2026-02-23 18:23:22');
INSERT INTO `media` VALUES('20','4c02026e5ea161cce1751b77beb66989.jpg','Vitamin B12.jpg','image/jpeg','704104','/uploads/media/4c02026e5ea161cce1751b77beb66989.jpg',NULL,NULL,NULL,NULL,'2026-02-23 18:24:22','2026-02-23 18:24:22');
INSERT INTO `media` VALUES('21','aafad6612f33ae5ef3ac5a361783979c.jpg','Vitamin B12.jpg','image/jpeg','704104','/uploads/media/aafad6612f33ae5ef3ac5a361783979c.jpg',NULL,NULL,NULL,NULL,'2026-02-23 18:43:21','2026-02-23 18:43:21');
INSERT INTO `media` VALUES('22','ee69976c5ec8780b1b8c269f3255efea.jpg','Vitamin B12.jpg','image/jpeg','704104','/uploads/media/ee69976c5ec8780b1b8c269f3255efea.jpg',NULL,NULL,NULL,NULL,'2026-02-23 18:47:02','2026-02-23 18:47:02');
INSERT INTO `media` VALUES('23','97425da3aefb18cdff19d4c64ff16228.jpg','Vitamin B12.jpg','image/jpeg','704104','/uploads/media/97425da3aefb18cdff19d4c64ff16228.jpg',NULL,NULL,NULL,NULL,'2026-02-23 18:50:06','2026-02-23 18:50:06');
INSERT INTO `media` VALUES('24','5db7b901715dd6c676c46dbb6b342510.jpg','Leucorrhoea Care - New.jpg','image/jpeg','741919','/uploads/media/5db7b901715dd6c676c46dbb6b342510.jpg',NULL,NULL,NULL,NULL,'2026-02-23 18:51:52','2026-02-23 18:51:52');
INSERT INTO `media` VALUES('25','51062496c055d96a776f9913123b3520.jpg','Active Heart Tonic_1.jpg','image/jpeg','965936','/uploads/media/51062496c055d96a776f9913123b3520.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:20:35','2026-02-23 19:20:35');
INSERT INTO `media` VALUES('26','770aff73b3c90fd3a0ec984e42d3e14c.jpg','Active Heart Tonic_1.jpg','image/jpeg','965936','/uploads/media/770aff73b3c90fd3a0ec984e42d3e14c.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:28:02','2026-02-23 19:28:02');
INSERT INTO `media` VALUES('27','0cd00ef5919e50766fb7a99336c41693.jpg','Active Heart Tonic_1.jpg','image/jpeg','965936','/uploads/media/0cd00ef5919e50766fb7a99336c41693.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:31:25','2026-02-23 19:31:25');
INSERT INTO `media` VALUES('28','7afc2a8dcdc091edfa42b15a27c8652f.jpg','Vitamin B12.jpg','image/jpeg','704104','/uploads/media/7afc2a8dcdc091edfa42b15a27c8652f.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:32:42','2026-02-23 19:32:42');
INSERT INTO `media` VALUES('29','5c80206c061c70f9302bf0020a844c57.jpg','Wholefood Multivitamin.jpg','image/jpeg','177621','/uploads/media/5c80206c061c70f9302bf0020a844c57.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:33:52','2026-02-23 19:33:52');
INSERT INTO `media` VALUES('30','9d2285351074b20de83bf1624be2b803.jpg','dehydrated-beetroot-powder.jpg','image/jpeg','380640','/uploads/media/9d2285351074b20de83bf1624be2b803.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:35:36','2026-02-23 19:35:36');
INSERT INTO `media` VALUES('31','0f3d56eda084c7522c1395b5ece429b4.jpg','natural-vitamin-c-powder.jpg','image/jpeg','1040114','/uploads/media/0f3d56eda084c7522c1395b5ece429b4.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:36:58','2026-02-23 19:36:58');
INSERT INTO `media` VALUES('32','8db886fceae06cc46d20c15af629f7a4.jpg','natural-vitamin-b12-powder.jpg','image/jpeg','794489','/uploads/media/8db886fceae06cc46d20c15af629f7a4.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:38:58','2026-02-23 19:38:58');
INSERT INTO `media` VALUES('33','05e6acf6e10f42b6f70b1acaebd072a7.jpg','dehydrated-alfalfa-leaves-powder.jpg','image/jpeg','381130','/uploads/media/05e6acf6e10f42b6f70b1acaebd072a7.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:39:59','2026-02-23 19:39:59');
INSERT INTO `media` VALUES('34','0fd0925622bb9d084f7e5d2b4fc3cc31.jpg','dehydrated-green-amla-powder.jpg','image/jpeg','364152','/uploads/media/0fd0925622bb9d084f7e5d2b4fc3cc31.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:40:48','2026-02-23 19:40:48');
INSERT INTO `media` VALUES('35','2921ab8581739a1f163f0c5f474f01e8.jpg','dehydrated-green-amla-powder.jpg','image/jpeg','364152','/uploads/media/2921ab8581739a1f163f0c5f474f01e8.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:44:47','2026-02-23 19:44:47');
INSERT INTO `media` VALUES('36','d5eb2bccf4cc60e940a98cfc9a7d3c53.jpg','dehydrated-barley-grass-powder.jpg','image/jpeg','406326','/uploads/media/d5eb2bccf4cc60e940a98cfc9a7d3c53.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:45:59','2026-02-23 19:45:59');
INSERT INTO `media` VALUES('37','496e2870b84a6c46be6a5412465bd730.jpg','dehydrated-bitter-gourd-powder.jpg','image/jpeg','390781','/uploads/media/496e2870b84a6c46be6a5412465bd730.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:46:37','2026-02-23 19:46:37');
INSERT INTO `media` VALUES('38','08db8c2575219c21f5e91707bb2fe247.jpg','dehydrated-bitter-gourd-powder.jpg','image/jpeg','390781','/uploads/media/08db8c2575219c21f5e91707bb2fe247.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:47:49','2026-02-23 19:47:49');
INSERT INTO `media` VALUES('39','f72ea1b581c8b4df247de7337efb66cf.jpg','dehydrated-coriander-leaves-powder.jpg','image/jpeg','395425','/uploads/media/f72ea1b581c8b4df247de7337efb66cf.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:49:21','2026-02-23 19:49:21');
INSERT INTO `media` VALUES('40','1cd4c8ba38263e076d1c3d14cb6132f5.jpg','dehydrated-drumstick-powder.jpg','image/jpeg','380013','/uploads/media/1cd4c8ba38263e076d1c3d14cb6132f5.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:49:46','2026-02-23 19:49:46');
INSERT INTO `media` VALUES('41','6c166792dc90ddd22f031eee11a2ac31.jpg','dehydrated-fenugreek-kasuri-methi-leaves-powder.jpg','image/jpeg','375999','/uploads/media/6c166792dc90ddd22f031eee11a2ac31.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:50:13','2026-02-23 19:50:13');
INSERT INTO `media` VALUES('42','ce2a37e81851b73789652cf14619b366.jpg','dehydrated-green-ginger-powder.jpg','image/jpeg','398614','/uploads/media/ce2a37e81851b73789652cf14619b366.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:50:53','2026-02-23 19:50:53');
INSERT INTO `media` VALUES('43','5c7a0a23a2cf162498646403b228fa34.jpg','dehydrated-mint-phudina-leaves-powder.jpg','image/jpeg','404342','/uploads/media/5c7a0a23a2cf162498646403b228fa34.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:51:59','2026-02-23 19:51:59');
INSERT INTO `media` VALUES('44','cca5d7972d8d16c61f4480f12a58e76b.jpg','Moringa.jpg','image/jpeg','737717','/uploads/media/cca5d7972d8d16c61f4480f12a58e76b.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:53:06','2026-02-23 19:53:06');
INSERT INTO `media` VALUES('45','db80fca2af7e21bff24a254120b0f282.jpg','dehydrated-pumpkin-powder.jpg','image/jpeg','384703','/uploads/media/db80fca2af7e21bff24a254120b0f282.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:53:39','2026-02-23 19:53:39');
INSERT INTO `media` VALUES('46','dad88d812d417d8c882a26bb57924022.jpg','dehydrated-radish-powder.jpg','image/jpeg','370102','/uploads/media/dad88d812d417d8c882a26bb57924022.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:55:49','2026-02-23 19:55:49');
INSERT INTO `media` VALUES('47','f7d76ed3ee9bb46638e7edaac59cf041.jpg','dehydrated-papaya-leaves-powder.jpg','image/jpeg','404248','/uploads/media/f7d76ed3ee9bb46638e7edaac59cf041.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:56:18','2026-02-23 19:56:18');
INSERT INTO `media` VALUES('48','3e6711a75ee005b70c76731580447893.jpg','dehydrated-spinach-leaves-powder.jpg','image/jpeg','389545','/uploads/media/3e6711a75ee005b70c76731580447893.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:56:45','2026-02-23 19:56:45');
INSERT INTO `media` VALUES('49','efac6a9557ac5fd1e53edf4714a60de9.jpg','dehydrated-spirulina-powder.jpg','image/jpeg','395334','/uploads/media/efac6a9557ac5fd1e53edf4714a60de9.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:57:32','2026-02-23 19:57:32');
INSERT INTO `media` VALUES('50','8ee4204d565652d0aedbc8302100cac7.jpg','dehydrated-suran-jimikand-powder.jpg','image/jpeg','366259','/uploads/media/8ee4204d565652d0aedbc8302100cac7.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:58:02','2026-02-23 19:58:02');
INSERT INTO `media` VALUES('51','97c10db850a2536e00f01ff9b9f4042c.jpg','dehydrated-tulsi-basil-leaves-powder.jpg','image/jpeg','420652','/uploads/media/97c10db850a2536e00f01ff9b9f4042c.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:58:33','2026-02-23 19:58:33');
INSERT INTO `media` VALUES('52','1fe73fdd69d11585cedd3452c75b2ce5.jpg','natural-wheat-o-grass-powder.jpg','image/jpeg','741937','/uploads/media/1fe73fdd69d11585cedd3452c75b2ce5.jpg',NULL,NULL,NULL,NULL,'2026-02-23 19:59:12','2026-02-23 19:59:12');
INSERT INTO `media` VALUES('53','d2428e39e3a74c0e6861806054252af4.jpg','Organic Certificate_0.jpg','image/jpeg','824851','/uploads/media/d2428e39e3a74c0e6861806054252af4.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:01:39','2026-02-23 20:01:39');
INSERT INTO `media` VALUES('54','e4dcfb9e54713bab579918855f97513f.jpg','Organic Certificate_0.jpg','image/jpeg','824851','/uploads/media/e4dcfb9e54713bab579918855f97513f.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:02:20','2026-02-23 20:02:20');
INSERT INTO `media` VALUES('55','563008605243380bc55bb4d4b7c9cdcd.jpg','ISO 22000 2018 Certificate_0.jpg','image/jpeg','775051','/uploads/media/563008605243380bc55bb4d4b7c9cdcd.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:02:55','2026-02-23 20:02:55');
INSERT INTO `media` VALUES('56','462901144dcb6f416c2dc4ae4483c407.jpg','Organic Certificate_0.jpg','image/jpeg','824851','/uploads/media/462901144dcb6f416c2dc4ae4483c407.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:03:18','2026-02-23 20:03:18');
INSERT INTO `media` VALUES('57','27ed31ee6b6a73a4f59f846a364038f4.jpg','WHO-GMP Certificate_0.jpg','image/jpeg','853195','/uploads/media/27ed31ee6b6a73a4f59f846a364038f4.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:03:37','2026-02-23 20:03:37');
INSERT INTO `media` VALUES('58','719af27150537ed1e89a3fceff7105c2.jpg','FSSAI License_0.jpg','image/jpeg','1086422','/uploads/media/719af27150537ed1e89a3fceff7105c2.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:04:27','2026-02-23 20:04:27');
INSERT INTO `media` VALUES('59','d15c519e7f619c0819bd135f14536c15.jpg','HACCP Certificate.jpg','image/jpeg','774746','/uploads/media/d15c519e7f619c0819bd135f14536c15.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:05:09','2026-02-23 20:05:09');
INSERT INTO `media` VALUES('60','bffd6408ebfecd8125ea8d14f11d6dae.jpg','HACCP Certificate.jpg','image/jpeg','774746','/uploads/media/bffd6408ebfecd8125ea8d14f11d6dae.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:05:42','2026-02-23 20:05:42');
INSERT INTO `media` VALUES('61','46256213b04d3543f57ef66049ffad52.jpg','USFDA Certificate.jpg','image/jpeg','598824','/uploads/media/46256213b04d3543f57ef66049ffad52.jpg',NULL,NULL,NULL,NULL,'2026-02-23 20:06:14','2026-02-23 20:06:14');


-- Table structure for `menu_items`
DROP TABLE IF EXISTS `menu_items`;
CREATE TABLE `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_foreign` (`menu_id`),
  KEY `menu_items_page_id_foreign` (`page_id`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_items_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `menu_items`
INSERT INTO `menu_items` VALUES('1','1',NULL,'Home','/home','1','0');
INSERT INTO `menu_items` VALUES('2','1',NULL,'About','/about','2','1');
INSERT INTO `menu_items` VALUES('4','1',NULL,'Products','/product-gallery','4','7');
INSERT INTO `menu_items` VALUES('7','1',NULL,'Contact','/contact','7','8');
INSERT INTO `menu_items` VALUES('8','1',NULL,'Certification','/certification','9','5');
INSERT INTO `menu_items` VALUES('9','1',NULL,'Process','/process','10','6');
INSERT INTO `menu_items` VALUES('10','1',NULL,'Company Profile','/company-profile','11','3');


-- Table structure for `menus`
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `menus`
INSERT INTO `menus` VALUES('1','Main Menu','header','0');


-- Table structure for `node`
DROP TABLE IF EXISTS `node`;
CREATE TABLE `node` (
  `nid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a node.',
  `vid` int(10) unsigned DEFAULT NULL COMMENT 'The current node_revision.vid version identifier.',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT 'The node_type.type of this node.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'The languages.language of this node.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The title of this node, always treated as non-markup plain text.',
  `uid` int(11) NOT NULL DEFAULT 0 COMMENT 'The users.uid that owns this node; initially, this is the user that created it.',
  `status` int(11) NOT NULL DEFAULT 1 COMMENT 'Boolean indicating whether the node is published (visible to non-administrators).',
  `created` int(11) NOT NULL DEFAULT 0 COMMENT 'The Unix timestamp when the node was created.',
  `changed` int(11) NOT NULL DEFAULT 0 COMMENT 'The Unix timestamp when the node was most recently saved.',
  `comment` int(11) NOT NULL DEFAULT 0 COMMENT 'Whether comments are allowed on this node: 0 = no, 1 = closed (read only), 2 = open (read/write).',
  `promote` int(11) NOT NULL DEFAULT 0 COMMENT 'Boolean indicating whether the node should be displayed on the front page.',
  `sticky` int(11) NOT NULL DEFAULT 0 COMMENT 'Boolean indicating whether the node should be displayed at the top of lists in which it appears.',
  `tnid` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'The translation set id for this node, which equals the node id of the source post in each set.',
  `translate` int(11) NOT NULL DEFAULT 0 COMMENT 'A boolean indicating whether this translation page needs to be updated.',
  PRIMARY KEY (`nid`),
  UNIQUE KEY `vid` (`vid`),
  KEY `node_changed` (`changed`),
  KEY `node_created` (`created`),
  KEY `node_frontpage` (`promote`,`status`,`sticky`,`created`),
  KEY `node_status_type` (`status`,`type`,`nid`),
  KEY `node_title_type` (`title`,`type`(4)),
  KEY `node_type` (`type`(4)),
  KEY `uid` (`uid`),
  KEY `tnid` (`tnid`),
  KEY `translate` (`translate`),
  KEY `language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='The base table for nodes.';

-- Dumping data for `node`
INSERT INTO `node` VALUES('9','9','product','und','Alfalfa Leaves','1','1','1486009956','1606306225','1','1','0','0','0');
INSERT INTO `node` VALUES('10','10','product','und','Beet Root','1','1','1486012098','1546069861','1','1','0','0','0');
INSERT INTO `node` VALUES('11','11','product','und','Bottle Gourd (Lauki) (Dudhi)','1','1','1486012298','1546070311','1','1','0','0','0');
INSERT INTO `node` VALUES('12','12','product','und','Coriander Leaves','1','1','1486012620','1546070388','1','1','0','0','0');
INSERT INTO `node` VALUES('13','13','product','und','Fenugreek Leaves (Kasuri Methi)','1','1','1486013762','1546070647','1','1','0','0','0');
INSERT INTO `node` VALUES('14','14','product','und','Amla (Indian Gooseberry)','1','1','1486014308','1546069483','1','1','0','0','0');
INSERT INTO `node` VALUES('15','15','product','und','Ginger (Raw Ginger)','1','1','1486014443','1546070753','1','1','0','0','0');
INSERT INTO `node` VALUES('16','16','product','und','Mint Leaves','1','1','1486015404','1546070876','1','1','0','0','0');
INSERT INTO `node` VALUES('17','17','product','und','Moringa Leaves','1','1','1486015502','1546070967','1','1','0','0','0');
INSERT INTO `node` VALUES('18','18','product','und','Pumpkin','1','1','1486015611','1546071413','1','1','0','0','0');
INSERT INTO `node` VALUES('19','19','product','und','Radish','1','1','1486015682','1546071466','1','1','0','0','0');
INSERT INTO `node` VALUES('20','20','product','und','Spinach Leaves (Palak)','1','1','1486019280','1546071882','1','1','0','0','0');
INSERT INTO `node` VALUES('22','22','product','und','Wheat Grass','1','1','1486019421','1546072649','1','1','0','0','0');
INSERT INTO `node` VALUES('31','31','product','und','25. Natural Vitamin B-Complex Powder','1','1','1486100670','1555227025','1','1','0','0','0');
INSERT INTO `node` VALUES('32','32','product','und','1. Natural Vitamin B12 Powder','1','1','1486100696','1555226081','1','1','0','0','0');
INSERT INTO `node` VALUES('33','33','product','und','24. Natural Vitamin C Powder','1','1','1486100730','1555226962','1','1','0','0','0');
INSERT INTO `node` VALUES('37','37','product','und','14. Natural Multi-Vitamins Powder','1','1','1486100832','1555226341','1','1','0','0','0');
INSERT INTO `node` VALUES('46','46','product','und','Bitter Gourd (Karela) ','15','1','1487393769','1546070182','1','1','0','0','0');
INSERT INTO `node` VALUES('47','47','product','und','Suran (Jimikand)','15','1','1487393894','1546072086','1','1','0','0','0');
INSERT INTO `node` VALUES('48','48','product','und','Barley Grass','15','1','1490443810','1546069774','1','1','0','0','0');
INSERT INTO `node` VALUES('51','51','product','und','Drumstick (Moringa Pod)','15','1','1490444362','1546070586','1','1','0','0','0');
INSERT INTO `node` VALUES('52','52','product','und','Raw Papaya','15','1','1490444580','1546071516','1','1','0','0','0');
INSERT INTO `node` VALUES('53','53','product','und','Spirulina','15','1','1490444849','1546071956','1','1','0','0','0');
INSERT INTO `node` VALUES('54','54','product','und','Tulsi (Holy Basil)','15','1','1490445062','1546072207','1','1','0','0','0');
INSERT INTO `node` VALUES('55','55','product','und','2.Turmeric (Raw Turmeric)','15','1','1490445196','1606306877','1','1','0','0','0');


-- Table structure for `page_categories`
DROP TABLE IF EXISTS `page_categories`;
CREATE TABLE `page_categories` (
  `page_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`page_id`,`category_id`),
  KEY `page_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `page_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `page_categories_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `page_categories`
INSERT INTO `page_categories` VALUES('8','1');


-- Table structure for `page_tags`
DROP TABLE IF EXISTS `page_tags`;
CREATE TABLE `page_tags` (
  `page_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`page_id`,`tag_id`),
  KEY `page_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `page_tags_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `page_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `page_views`
DROP TABLE IF EXISTS `page_views`;
CREATE TABLE `page_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `path` varchar(191) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `referrer` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `session_id` varchar(191) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_page_views_created_at` (`created_at`),
  KEY `idx_page_views_page_id` (`page_id`),
  KEY `idx_page_views_source` (`source`),
  CONSTRAINT `fk_page_views_page_id` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `page_views`
INSERT INTO `page_views` VALUES('1','1','/home','referral','http://pankhcms.dvl.to/admin/messages','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 11:40:09');
INSERT INTO `page_views` VALUES('2','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 11:40:17');
INSERT INTO `page_views` VALUES('3','1','/home','referral','http://pankhcms.dvl.to/admin/messages','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 11:45:12');
INSERT INTO `page_views` VALUES('4','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 11:45:54');
INSERT INTO `page_views` VALUES('5','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 12:13:31');
INSERT INTO `page_views` VALUES('6','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 12:33:47');
INSERT INTO `page_views` VALUES('7','2','/about','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 12:33:59');
INSERT INTO `page_views` VALUES('8','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 12:34:32');
INSERT INTO `page_views` VALUES('9','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','69a8f3a7cba747d13a5461c2358795cd','2026-02-22 12:36:50');
INSERT INTO `page_views` VALUES('10','1','/home','referral','https://hpanel.hostinger.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','qhog4sqpv0m6ftfhaa1bmneu75','2026-02-22 15:05:24');
INSERT INTO `page_views` VALUES('11','1','/home','referral','https://organicdefoods.com/admin/settings?status=updated','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 16:32:02');
INSERT INTO `page_views` VALUES('12','1','/home','referral','https://organicdefoods.com/admin/profile','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 16:40:55');
INSERT INTO `page_views` VALUES('13','1','/home','referral','https://organicdefoods.com/admin/profile','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 16:49:07');
INSERT INTO `page_views` VALUES('14','1','/home','referral','https://organicdefoods.com/admin/settings?status=updated','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:00:20');
INSERT INTO `page_views` VALUES('15','1','/home','referral','https://organicdefoods.com/admin/menus','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:12:27');
INSERT INTO `page_views` VALUES('16','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:12:29');
INSERT INTO `page_views` VALUES('17','1','/home','referral','https://organicdefoods.com/admin/pages?saved=1','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:19:13');
INSERT INTO `page_views` VALUES('18','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:19:15');
INSERT INTO `page_views` VALUES('19','1','/home','referral','https://organicdefoods.com/admin/pages?saved=1','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:20:32');
INSERT INTO `page_views` VALUES('20','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:20:33');
INSERT INTO `page_views` VALUES('21','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:21:37');
INSERT INTO `page_views` VALUES('22','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:24:11');
INSERT INTO `page_views` VALUES('23','1','/home','referral','https://organicdefoods.com/admin/pages?saved=1','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:28:17');
INSERT INTO `page_views` VALUES('24','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:28:19');
INSERT INTO `page_views` VALUES('25','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:30:25');
INSERT INTO `page_views` VALUES('26','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:33:40');
INSERT INTO `page_views` VALUES('27','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:35:35');
INSERT INTO `page_views` VALUES('28','6','/products','referral','https://organicdefoods.com/certification','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:36:03');
INSERT INTO `page_views` VALUES('29','1','/home','referral','https://organicdefoods.com/admin/pages/7/edit','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:49:11');
INSERT INTO `page_views` VALUES('30','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:49:13');
INSERT INTO `page_views` VALUES('31','1','/home','referral','https://organicdefoods.com/admin/menus?menu_id=1','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:53:35');
INSERT INTO `page_views` VALUES('32','10','/process','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:53:38');
INSERT INTO `page_views` VALUES('33','1','/home','referral','https://organicdefoods.com/admin/menus?menu_id=1','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:59:09');
INSERT INTO `page_views` VALUES('34','11','/company-profile','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:59:12');
INSERT INTO `page_views` VALUES('35','11','/company-profile','referral','https://organicdefoods.com/company-profile','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 17:59:47');
INSERT INTO `page_views` VALUES('36','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 18:00:51');
INSERT INTO `page_views` VALUES('37','6','/products','referral','https://organicdefoods.com/company-profile','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','07r8qobn9hu1ofdhja49c4nd1u','2026-02-22 18:09:22');
INSERT INTO `page_views` VALUES('38','1','/home','direct',NULL,'203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','52q9sdq7rqgmg2di93qrmmg0n5','2026-02-22 18:19:06');
INSERT INTO `page_views` VALUES('39','8','/geofresh-vitamin-d3-k2','direct',NULL,'203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','6i436d4g8ga8v2tr1kklmsv6dl','2026-02-22 18:25:43');
INSERT INTO `page_views` VALUES('40','1','/home','direct',NULL,'203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','6i436d4g8ga8v2tr1kklmsv6dl','2026-02-22 19:09:47');
INSERT INTO `page_views` VALUES('41','2','/about','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','6i436d4g8ga8v2tr1kklmsv6dl','2026-02-22 19:09:51');
INSERT INTO `page_views` VALUES('42','11','/company-profile','referral','https://organicdefoods.com/about','203.192.227.246','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','6i436d4g8ga8v2tr1kklmsv6dl','2026-02-22 19:09:53');
INSERT INTO `page_views` VALUES('43','1','/home','direct',NULL,'203.192.227.246','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','fssm3gqbnm8mkd1cgnlrt5ij24','2026-02-23 02:23:59');
INSERT INTO `page_views` VALUES('44','11','/company-profile','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','fssm3gqbnm8mkd1cgnlrt5ij24','2026-02-23 02:24:54');
INSERT INTO `page_views` VALUES('45','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','fssm3gqbnm8mkd1cgnlrt5ij24','2026-02-23 02:25:07');
INSERT INTO `page_views` VALUES('46','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','fssm3gqbnm8mkd1cgnlrt5ij24','2026-02-23 02:25:25');
INSERT INTO `page_views` VALUES('47','9','/certification','referral','https://organicdefoods.com/','203.192.227.246','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','fssm3gqbnm8mkd1cgnlrt5ij24','2026-02-23 02:25:40');
INSERT INTO `page_views` VALUES('48','10','/process','referral','https://organicdefoods.com/certification','203.192.227.246','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36','fssm3gqbnm8mkd1cgnlrt5ij24','2026-02-23 02:25:51');
INSERT INTO `page_views` VALUES('49','1','/home','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','dhd70bg6f43hnhq0da10rpb5t3','2026-02-23 06:56:09');
INSERT INTO `page_views` VALUES('50','6','/products','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','dhd70bg6f43hnhq0da10rpb5t3','2026-02-23 06:56:18');
INSERT INTO `page_views` VALUES('51','8','/geofresh-vitamin-d3-k2','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','dhd70bg6f43hnhq0da10rpb5t3','2026-02-23 06:57:10');
INSERT INTO `page_views` VALUES('52','1','/home','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','osujjt6pj0mie9p8i5n1ifkj9d','2026-02-23 12:16:27');
INSERT INTO `page_views` VALUES('53','1','/home','referral','https://organicdefoods.com/admin/themes?status=updated','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:18:03');
INSERT INTO `page_views` VALUES('54','1','/home','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:18:05');
INSERT INTO `page_views` VALUES('55','1','/home','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:18:37');
INSERT INTO `page_views` VALUES('56','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:19:12');
INSERT INTO `page_views` VALUES('57','9','/certification','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:19:19');
INSERT INTO `page_views` VALUES('58','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:20:41');
INSERT INTO `page_views` VALUES('59','9','/certification','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:20:48');
INSERT INTO `page_views` VALUES('60','1','/home','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:21:51');
INSERT INTO `page_views` VALUES('61','1','/home','referral','https://organicdefoods.com/admin/themes?status=updated','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:23:50');
INSERT INTO `page_views` VALUES('62','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:24:56');
INSERT INTO `page_views` VALUES('63','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:28:27');
INSERT INTO `page_views` VALUES('64','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:28:33');
INSERT INTO `page_views` VALUES('65','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:28:34');
INSERT INTO `page_views` VALUES('66','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:28:34');
INSERT INTO `page_views` VALUES('67','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:28:35');
INSERT INTO `page_views` VALUES('68','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:28:35');
INSERT INTO `page_views` VALUES('69','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:29:08');
INSERT INTO `page_views` VALUES('70','9','/certification','referral','https://organicdefoods.com/','203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','nkstne9ic1qvms6d4lf3dmgc4q','2026-02-23 12:30:23');
INSERT INTO `page_views` VALUES('71','1','/home','direct',NULL,'203.192.227.16','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','fhj9rdu8hrnbnqvsamroel6c4d','2026-02-23 12:53:02');
INSERT INTO `page_views` VALUES('72','1','/home','referral','http://pankhcms.dvl.to/admin/settings?status=updated','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','3c62200a3644652d9d040c392a4b1b20','2026-02-23 13:04:27');
INSERT INTO `page_views` VALUES('73','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','3c62200a3644652d9d040c392a4b1b20','2026-02-23 13:04:48');
INSERT INTO `page_views` VALUES('74','1','/home','referral','http://pankhcms.dvl.to/admin/settings?status=updated','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','3c62200a3644652d9d040c392a4b1b20','2026-02-23 13:17:23');
INSERT INTO `page_views` VALUES('75','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:37:30');
INSERT INTO `page_views` VALUES('76','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:38:21');
INSERT INTO `page_views` VALUES('77','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:38:33');
INSERT INTO `page_views` VALUES('78','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:39:33');
INSERT INTO `page_views` VALUES('79','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:39:58');
INSERT INTO `page_views` VALUES('80','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:40:26');
INSERT INTO `page_views` VALUES('81','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:43:08');
INSERT INTO `page_views` VALUES('82','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:44:58');
INSERT INTO `page_views` VALUES('83','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:45:36');
INSERT INTO `page_views` VALUES('84','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:46:46');
INSERT INTO `page_views` VALUES('85','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:46:57');
INSERT INTO `page_views` VALUES('86','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','22115bfa4f8bd3fc65a0af8eff2e074a','2026-02-23 13:52:26');
INSERT INTO `page_views` VALUES('87','1','/home','direct',NULL,'192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0b1f7569e0471933b8746357bef10343','2026-02-23 13:53:55');
INSERT INTO `page_views` VALUES('88','9','/certification','referral','http://pankhcms.dvl.to/','192.168.1.37','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0b1f7569e0471933b8746357bef10343','2026-02-23 13:54:06');
INSERT INTO `page_views` VALUES('89','1','/home','direct',NULL,'192.168.1.40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','d570901d2bbe9fe4995913954f32b4fb','2026-02-23 15:09:40');
INSERT INTO `page_views` VALUES('90','1','/home','referral','http://pankhcms.dvl.to/admin','192.168.1.40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:13:19');
INSERT INTO `page_views` VALUES('91','1','/home','direct',NULL,'192.168.1.40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:14:00');
INSERT INTO `page_views` VALUES('92','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:14:18');
INSERT INTO `page_views` VALUES('93','9','/certification','referral','http://pankhcms.dvl.to/about','192.168.1.40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:14:46');
INSERT INTO `page_views` VALUES('94','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:25:09');
INSERT INTO `page_views` VALUES('95','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:25:15');
INSERT INTO `page_views` VALUES('96','2','/about','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:25:30');
INSERT INTO `page_views` VALUES('97','1','/home','referral','http://pankhcms.dvl.to/about','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:25:40');
INSERT INTO `page_views` VALUES('98','1','/home','referral','http://pankhcms.dvl.to/home','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:25:51');
INSERT INTO `page_views` VALUES('99','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 15:26:05');
INSERT INTO `page_views` VALUES('100','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:47:35');
INSERT INTO `page_views` VALUES('101','1','/home','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:47:42');
INSERT INTO `page_views` VALUES('102','6','/products','referral','http://pankhcms.dvl.to/home','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:49:42');
INSERT INTO `page_views` VALUES('103','6','/products','referral','http://pankhcms.dvl.to/home','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:51:11');
INSERT INTO `page_views` VALUES('104','9','/certification','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:51:22');
INSERT INTO `page_views` VALUES('105','11','/company-profile','referral','http://pankhcms.dvl.to/contact','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:54:23');
INSERT INTO `page_views` VALUES('106','11','/company-profile','referral','http://pankhcms.dvl.to/contact','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:55:47');
INSERT INTO `page_views` VALUES('107','9','/certification','referral','http://pankhcms.dvl.to/company-profile','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:55:53');
INSERT INTO `page_views` VALUES('108','1','/home','referral','http://pankhcms.dvl.to/certification','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:56:04');
INSERT INTO `page_views` VALUES('109','6','/products','referral','http://pankhcms.dvl.to/home','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:56:32');
INSERT INTO `page_views` VALUES('110','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 16:57:55');
INSERT INTO `page_views` VALUES('111','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:19:24');
INSERT INTO `page_views` VALUES('112','6','/products','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:19:28');
INSERT INTO `page_views` VALUES('113','6','/products','referral','http://pankhcms.dvl.to/home','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:22:31');
INSERT INTO `page_views` VALUES('114','6','/products','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:22:53');
INSERT INTO `page_views` VALUES('115','6','/products','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:23:17');
INSERT INTO `page_views` VALUES('116','6','/products','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:24:37');
INSERT INTO `page_views` VALUES('117','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:27:57');
INSERT INTO `page_views` VALUES('118','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:28:01');
INSERT INTO `page_views` VALUES('119','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:28:05');
INSERT INTO `page_views` VALUES('120','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:28:08');
INSERT INTO `page_views` VALUES('121','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:28:10');
INSERT INTO `page_views` VALUES('122','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:28:13');
INSERT INTO `page_views` VALUES('123','6','/products','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:37:24');
INSERT INTO `page_views` VALUES('124','4','/product-gallery','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:37:30');
INSERT INTO `page_views` VALUES('125','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:37:38');
INSERT INTO `page_views` VALUES('126','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:38:28');
INSERT INTO `page_views` VALUES('127','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:39:49');
INSERT INTO `page_views` VALUES('128','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:40:05');
INSERT INTO `page_views` VALUES('129','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:54:21');
INSERT INTO `page_views` VALUES('130','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:56:54');
INSERT INTO `page_views` VALUES('131','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:57:54');
INSERT INTO `page_views` VALUES('132','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:57:59');
INSERT INTO `page_views` VALUES('133','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:58:02');
INSERT INTO `page_views` VALUES('134','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 17:58:04');
INSERT INTO `page_views` VALUES('135','4','/product-gallery','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:01:14');
INSERT INTO `page_views` VALUES('136','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:01:24');
INSERT INTO `page_views` VALUES('137','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:03:04');
INSERT INTO `page_views` VALUES('138','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:04:13');
INSERT INTO `page_views` VALUES('139','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:07:44');
INSERT INTO `page_views` VALUES('140','28','/14-natural-multi-vitamins-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:07:56');
INSERT INTO `page_views` VALUES('141','6','/products','referral','http://pankhcms.dvl.to/14-natural-multi-vitamins-powder','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:12:07');
INSERT INTO `page_views` VALUES('142','4','/product-gallery','referral','http://pankhcms.dvl.to/products','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:13:32');
INSERT INTO `page_views` VALUES('143','26','/1-natural-vitamin-b12-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:13:40');
INSERT INTO `page_views` VALUES('144','1','/home','referral','http://pankhcms.dvl.to/admin/pages/26/update','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:23:45');
INSERT INTO `page_views` VALUES('145','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:23:51');
INSERT INTO `page_views` VALUES('146','26','/1-natural-vitamin-b12-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:24:01');
INSERT INTO `page_views` VALUES('147','1','/home','referral','http://pankhcms.dvl.to/admin/pages/26/update','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:24:50');
INSERT INTO `page_views` VALUES('148','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:24:57');
INSERT INTO `page_views` VALUES('149','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:25:05');
INSERT INTO `page_views` VALUES('150','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:31:31');
INSERT INTO `page_views` VALUES('151','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:31:47');
INSERT INTO `page_views` VALUES('152','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:32:17');
INSERT INTO `page_views` VALUES('153','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:32:23');
INSERT INTO `page_views` VALUES('154','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:34:30');
INSERT INTO `page_views` VALUES('155','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:34:37');
INSERT INTO `page_views` VALUES('156','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:34:51');
INSERT INTO `page_views` VALUES('157','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:35:17');
INSERT INTO `page_views` VALUES('158','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:43:37');
INSERT INTO `page_views` VALUES('159','4','/product-gallery','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 18:44:00');
INSERT INTO `page_views` VALUES('160','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:07:20');
INSERT INTO `page_views` VALUES('161','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:32:00');
INSERT INTO `page_views` VALUES('162','26','/1-natural-vitamin-b12-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:32:19');
INSERT INTO `page_views` VALUES('163','1','/home','referral','http://pankhcms.dvl.to/admin/pages?saved=1','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:33:03');
INSERT INTO `page_views` VALUES('164','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:33:08');
INSERT INTO `page_views` VALUES('165','28','/14-natural-multi-vitamins-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:33:14');
INSERT INTO `page_views` VALUES('166','1','/home','referral','http://pankhcms.dvl.to/admin/pages?saved=1','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:35:50');
INSERT INTO `page_views` VALUES('167','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:35:56');
INSERT INTO `page_views` VALUES('168','27','/24-natural-vitamin-c-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:36:11');
INSERT INTO `page_views` VALUES('169','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:37:31');
INSERT INTO `page_views` VALUES('170','25','/25-natural-vitamin-b-complex-powder','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:37:52');
INSERT INTO `page_views` VALUES('171','12','/alfalfa-leaves','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:39:12');
INSERT INTO `page_views` VALUES('172','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:40:16');
INSERT INTO `page_views` VALUES('173','17','/amla-indian-gooseberry','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:40:24');
INSERT INTO `page_views` VALUES('174','31','/barley-grass','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:40:55');
INSERT INTO `page_views` VALUES('175','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:43:50');
INSERT INTO `page_views` VALUES('176','17','/amla-indian-gooseberry','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:44:02');
INSERT INTO `page_views` VALUES('177','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:45:27');
INSERT INTO `page_views` VALUES('178','31','/barley-grass','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:45:35');
INSERT INTO `page_views` VALUES('179','29','/bitter-gourd-karela','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:46:16');
INSERT INTO `page_views` VALUES('180','14','/bottle-gourd-lauki-dudhi','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:46:56');
INSERT INTO `page_views` VALUES('181','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:48:35');
INSERT INTO `page_views` VALUES('182','15','/coriander-leaves','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:48:45');
INSERT INTO `page_views` VALUES('183','32','/drumstick-moringa-pod','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:48:49');
INSERT INTO `page_views` VALUES('184','16','/fenugreek-leaves-kasuri-methi','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:48:53');
INSERT INTO `page_views` VALUES('185','18','/ginger-raw-ginger','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:48:56');
INSERT INTO `page_views` VALUES('186','19','/mint-leaves','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:49:00');
INSERT INTO `page_views` VALUES('187','20','/moringa-leaves','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:49:02');
INSERT INTO `page_views` VALUES('188','21','/pumpkin','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:49:06');
INSERT INTO `page_views` VALUES('189','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:10');
INSERT INTO `page_views` VALUES('190','24','/wheat-grass','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:42');
INSERT INTO `page_views` VALUES('191','35','/tulsi-holy-basil','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:44');
INSERT INTO `page_views` VALUES('192','30','/suran-jimikand','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:48');
INSERT INTO `page_views` VALUES('193','34','/spirulina','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:50');
INSERT INTO `page_views` VALUES('194','23','/spinach-leaves-palak','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:53');
INSERT INTO `page_views` VALUES('195','33','/raw-papaya','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:56');
INSERT INTO `page_views` VALUES('196','22','/radish','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:54:59');
INSERT INTO `page_views` VALUES('197','4','/product-gallery','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 19:59:49');
INSERT INTO `page_views` VALUES('198','1','/home','referral','http://pankhcms.dvl.to/admin/pages?saved=1','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:00:22');
INSERT INTO `page_views` VALUES('199','9','/certification','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:00:27');
INSERT INTO `page_views` VALUES('200','1','/home','referral','http://pankhcms.dvl.to/admin/pages?saved=1','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:06:29');
INSERT INTO `page_views` VALUES('201','10','/process','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:06:34');
INSERT INTO `page_views` VALUES('202','4','/product-gallery','referral','http://pankhcms.dvl.to/process','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:06:41');
INSERT INTO `page_views` VALUES('203','1','/home','referral','http://pankhcms.dvl.to/product-gallery','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:07:06');
INSERT INTO `page_views` VALUES('204','1','/home','referral','http://pankhcms.dvl.to/admin/slider','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:14:38');
INSERT INTO `page_views` VALUES('205','1','/home','referral','http://pankhcms.dvl.to/admin/slider','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:17:05');
INSERT INTO `page_views` VALUES('206','1','/home','referral','http://pankhcms.dvl.to/admin/slider','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:19:56');
INSERT INTO `page_views` VALUES('207','1','/home','referral','http://pankhcms.dvl.to/admin/slider','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:21:16');
INSERT INTO `page_views` VALUES('208','1','/home','referral','http://pankhcms.dvl.to/admin/slider','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:23:13');
INSERT INTO `page_views` VALUES('209','15','/coriander-leaves','referral','http://pankhcms.dvl.to/','192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','274730eceb64c02b12d5dfff6f4537c8','2026-02-23 20:23:36');
INSERT INTO `page_views` VALUES('210','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0','bab4e4ff1a4957e73ed3de9dc1d3a143','2026-02-24 05:37:18');
INSERT INTO `page_views` VALUES('211','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0','bab4e4ff1a4957e73ed3de9dc1d3a143','2026-02-24 05:37:46');
INSERT INTO `page_views` VALUES('212','1','/home','direct',NULL,'192.168.1.35','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0','268aced39c126ee873365ab8db4536a5','2026-02-24 05:38:52');


-- Table structure for `pages`
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'page',
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `og_title` text DEFAULT NULL,
  `og_description` text DEFAULT NULL,
  `og_image` text DEFAULT NULL,
  `canonical_url` text DEFAULT NULL,
  `robots` varchar(255) DEFAULT NULL,
  `twitter_card` varchar(255) DEFAULT NULL,
  `twitter_site` varchar(255) DEFAULT NULL,
  `noindex` int(11) NOT NULL DEFAULT 0,
  `content_json` text DEFAULT NULL,
  `layout` varchar(255) NOT NULL DEFAULT 'default',
  `status` varchar(255) NOT NULL DEFAULT 'published',
  `featured_image` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `seo_title` text DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `seo_keywords` text DEFAULT NULL,
  `seo_image` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`),
  UNIQUE KEY `idx_pages_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `pages`
INSERT INTO `pages` VALUES('1',NULL,'page','Home','home',NULL,'Home - Organic Dehydrated Foods Pvt. Ltd.','Organic Dehydrated Foods Pvt. Ltd., Gujarat, India — Manufacturer, supplier & exporter of food supplements, herbal oil drops, organic dehydrated vegetables & herbal powders for natural wellness.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[]','default','published',NULL,'2026-02-19 18:20:13','2026-02-22 11:43:07',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('2',NULL,'page','About','about',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"text\",\"html\":\"<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container\\\">\\n<div class=\\\"row align-items-center g-5\\\"><!-- Image -->\\n<div class=\\\"col-lg-6\\\"><img class=\\\"img-fluid rounded shadow\\\" src=\\\"/themes/greenbs/assets/img/dehydrated_powder.jpg\\\" alt=\\\"Organic Dehydrated Foods Manufacturing Facility\\\"></div>\\n<!-- Content -->\\n<div class=\\\"col-lg-6\\\">\\n<h2 class=\\\"fw-bold mb-3\\\">About Organic Dehydrated Foods Pvt. Ltd.</h2>\\n<p>Established in 2016, Organic Dehydrated Foods Pvt. Ltd. is a certified manufacturer of food supplements, herbal oil drops, organic dehydrated vegetables, and herbal powders.</p>\\n<p>Our proprietary dehydration technology preserves natural nutrients, flavor, and medicinal value while maintaining the highest standards of purity and safety.</p>\\n<ul class=\\\"list-unstyled\\\">\\n<li>✔ ISO 22000:2018 &amp; HACCP Certified</li>\\n<li>✔ US-FDA &amp; WHO-GMP Compliance</li>\\n<li>✔ 100% Natural Products</li>\\n</ul>\\n</div>\\n</div>\\n</div>\\n</section>\\n<section class=\\\"py-5\\\">\\n<div class=\\\"container\\\">\\n<div class=\\\"row align-items-center g-5\\\"><!-- Content -->\\n<div class=\\\"col-lg-6 order-lg-1 order-2\\\">\\n<h2 class=\\\"fw-bold mb-3\\\">Natural Wellness Solutions</h2>\\n<p>We combine traditional herbal knowledge with advanced processing techniques to produce safe, effective, and high-quality natural products for global markets.</p>\\n<ul>\\n<li>Food Supplements</li>\\n<li>Herbal Oil Drops</li>\\n<li>Organic Dehydrated Vegetables</li>\\n<li>Herbal Powders</li>\\n</ul>\\n</div>\\n<!-- Image -->\\n<div class=\\\"col-lg-6 order-lg-2 order-1\\\"><img class=\\\"img-fluid rounded shadow\\\" src=\\\"/themes/greenbs/assets/img/product_display.jpg\\\" alt=\\\"Organic Herbal Products\\\"></div>\\n</div>\\n</div>\\n</section>\\n<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container text-center\\\">\\n<h2 class=\\\"fw-bold mb-4\\\">Quality &amp; Research</h2>\\n<p class=\\\"lead mx-auto\\\" style=\\\"max-width: 800px;\\\">Strict quality control measures are implemented at every stage of production. Our R&amp;D team continuously develops improved formulations to meet international standards and customer expectations.</p>\\n<img class=\\\"img-fluid rounded shadow mt-4\\\" src=\\\"/themes/greenbs/assets/img/quality_testing_lab.jpg\\\" alt=\\\"Quality Testing Laboratory\\\"></div>\\n</section>\\n<section class=\\\"py-5\\\">\\n<div class=\\\"container text-center\\\">\\n<h2 class=\\\"fw-bold mb-5\\\">Mission &amp; Vision</h2>\\n<div class=\\\"row g-4\\\">\\n<div class=\\\"col-md-6\\\">\\n<div class=\\\"card h-100 border-0 shadow\\\">\\n<div class=\\\"card-body\\\">\\n<h4 class=\\\"fw-bold\\\">Mission</h4>\\n<p>To deliver high-quality natural products globally while promoting health, sustainability, and ethical sourcing.</p>\\n</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-6\\\">\\n<div class=\\\"card h-100 border-0 shadow\\\">\\n<div class=\\\"card-body\\\">\\n<h4 class=\\\"fw-bold\\\">Vision</h4>\\n<p>To become a trusted global leader in natural wellness products with superior nutritional and medicinal value.</p>\\n</div>\\n</div>\\n</div>\\n</div>\\n</div>\\n</section>\"}]','default','published',NULL,'2026-02-19 18:20:31','2026-02-22 12:33:35',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('3',NULL,'page','Services','services',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[]','default','published',NULL,'2026-02-19 18:20:50','2026-02-20 07:40:06',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('4',NULL,'page','Product Gallery','product-gallery',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[]','default','published',NULL,'2026-02-19 18:21:07','2026-02-22 05:17:37',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('5',NULL,'page','Projects','projects',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[]','default','published',NULL,'2026-02-19 18:21:34','2026-02-19 18:21:34',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('6',NULL,'page','Products','products',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[]','default','published',NULL,'2026-02-19 18:21:52','2026-02-19 18:21:52',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('7',NULL,'page','Contact','contact',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[]','default','published',NULL,'2026-02-20 07:17:36','2026-02-20 07:17:36',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('8',NULL,'products','Geofresh - Vitamin D3 + K2','geofresh-vitamin-d3-k2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"This is product 1 Details summary\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/0cd00ef5919e50766fb7a99336c41693.jpg','2026-02-22 04:29:44','2026-02-23 19:31:29',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('9',NULL,'page','Certification','certification',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"text\",\"html\":\"<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container\\\">\\n<div class=\\\"row g-4\\\">\\n<div class=\\\"col-md-4\\\">\\n<div class=\\\"position-relative rounded border overflow-hidden shadow-sm\\\"><img class=\\\"img-fluid w-100\\\" style=\\\"aspect-ratio: 2/3; object-fit: cover;\\\" src=\\\"/uploads/media/563008605243380bc55bb4d4b7c9cdcd.jpg\\\" alt=\\\"ISO 22000 2018 Certificate\\\" width=\\\"1536\\\" height=\\\"2172\\\">\\n<div class=\\\"position-absolute bottom-0 start-0 w-100 bg-warning text-white text-center py-2\\\">ISO 22000 2018 Certificate</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-4\\\">\\n<div class=\\\"position-relative rounded border overflow-hidden shadow-sm\\\"><img class=\\\"img-fluid w-100\\\" style=\\\"aspect-ratio: 2/3; object-fit: cover;\\\" src=\\\"/uploads/media/462901144dcb6f416c2dc4ae4483c407.jpg\\\" alt=\\\"Organic Certificate\\\" width=\\\"2481\\\" height=\\\"3722\\\">\\n<div class=\\\"position-absolute bottom-0 start-0 w-100 bg-warning text-white text-center py-2\\\">Organic Certificate</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-4\\\">\\n<div class=\\\"position-relative rounded border overflow-hidden shadow-sm\\\"><img class=\\\"img-fluid w-100\\\" style=\\\"aspect-ratio: 2/3; object-fit: cover;\\\" src=\\\"/uploads/media/27ed31ee6b6a73a4f59f846a364038f4.jpg\\\" alt=\\\"WHO-GMP Certificate\\\" width=\\\"1536\\\" height=\\\"2172\\\">\\n<div class=\\\"position-absolute bottom-0 start-0 w-100 bg-warning text-white text-center py-2\\\">WHO-GMP Certificate</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-4\\\">\\n<div class=\\\"position-relative rounded border overflow-hidden shadow-sm\\\"><img class=\\\"img-fluid w-100\\\" style=\\\"aspect-ratio: 2/3; object-fit: cover;\\\" src=\\\"/uploads/media/719af27150537ed1e89a3fceff7105c2.jpg\\\" alt=\\\"FSSAI License\\\" width=\\\"1536\\\" height=\\\"2071\\\">\\n<div class=\\\"position-absolute bottom-0 start-0 w-100 bg-warning text-white text-center py-2\\\">FSSAI License</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-4\\\">\\n<div class=\\\"position-relative rounded border overflow-hidden shadow-sm\\\"><img class=\\\"img-fluid w-100\\\" style=\\\"aspect-ratio: 2/3; object-fit: cover;\\\" src=\\\"/uploads/media/d15c519e7f619c0819bd135f14536c15.jpg\\\" alt=\\\"HACCP Certificate\\\" width=\\\"1536\\\" height=\\\"2172\\\">\\n<div class=\\\"position-absolute bottom-0 start-0 w-100 bg-warning text-white text-center py-2\\\">HACCP Certificate</div>\\n</div>\\n</div>\\n<div class=\\\"col-md-4\\\">\\n<div class=\\\"position-relative rounded border overflow-hidden shadow-sm\\\"><img class=\\\"img-fluid w-100\\\" style=\\\"aspect-ratio: 2/3; object-fit: cover;\\\" src=\\\"/uploads/media/46256213b04d3543f57ef66049ffad52.jpg\\\" alt=\\\"USFDA Certificate\\\" width=\\\"1500\\\" height=\\\"1941\\\">\\n<div class=\\\"position-absolute bottom-0 start-0 w-100 bg-warning text-white text-center py-2\\\">USFDA Certificate</div>\\n</div>\\n</div>\\n</div>\\n</div>\\n</section>\"}]','default','published',NULL,'2026-02-22 17:05:25','2026-02-23 20:06:20',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('10',NULL,'page','Process','process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"text\",\"html\":\"<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container\\\">\\n<div class=\\\"row justify-content-center\\\">\\n<div class=\\\"col-lg-10\\\">\\n<h2 class=\\\"fw-bold mb-4 text-center\\\">Our Processing Method</h2>\\n<p class=\\\"lead text-muted\\\">Food dehydration is a proven preservation technique that removes moisture from fresh produce, preventing the growth of bacteria, yeast, and mold that cause spoilage. By reducing water content, the natural enzymatic activity that leads to ripening slows significantly, helping maintain product quality over time. Dehydrated foods become lighter, compact, and easy to store or transport, and they regain much of their original form when rehydrated.</p>\\n<p class=\\\"text-muted\\\">We process vegetables, herbs, and fruits using our proprietary <strong>Unique Dehydration Technique (UDT)</strong>. This advanced method ensures thorough drying while preserving the natural nutritional value, aroma, taste, flavor, and color of the original product.</p>\\n<div class=\\\"mt-4\\\">\\n<h5 class=\\\"fw-semibold mb-3\\\">Benefits of UDT</h5>\\n<ul class=\\\"list-group list-group-flush\\\">\\n<li class=\\\"list-group-item bg-transparent\\\">✔ Raw materials are carefully sorted, washed, sanitized or blanched, cut, and loaded into the dehydrator</li>\\n<li class=\\\"list-group-item bg-transparent\\\">✔ Gradual drying prevents structural damage and preserves product integrity</li>\\n<li class=\\\"list-group-item bg-transparent\\\">✔ Natural aroma, flavor, pungency, and taste are retained close to their original state</li>\\n<li class=\\\"list-group-item bg-transparent\\\">✔ Cost-effective processing with high efficiency</li>\\n<li class=\\\"list-group-item bg-transparent\\\">✔ Significantly extended shelf life without compromising quality</li>\\n</ul>\\n</div>\\n</div>\\n</div>\\n</div>\\n</section>\"}]','default','published',NULL,'2026-02-22 17:52:37','2026-02-22 17:52:37',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('11',NULL,'page','Company Profile','company-profile',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"text\",\"html\":\"<section class=\\\"py-5 bg-light\\\">\\n<div class=\\\"container\\\"><!-- Heading -->\\n<div class=\\\"text-center mb-5\\\">\\n<h2 class=\\\"fw-bold\\\">Company Profile</h2>\\n<p class=\\\"text-muted mb-0\\\">Organic Dehydrated Foods Pvt. Ltd. &mdash; Delivering Natural Wellness Worldwide</p>\\n</div>\\n<!-- About -->\\n<div class=\\\"row mb-5\\\">\\n<div class=\\\"col-lg-10 mx-auto\\\">\\n<p class=\\\"text-muted\\\"><strong>Organic Dehydrated Foods Pvt. Ltd.</strong> is located near Ankleshwar GIDC, District Bharuch, Gujarat (India). We are a leading manufacturer, supplier, and exporter of premium food supplement products, herbal oil drops, organic vegetables, and herbal powders.</p>\\n<p class=\\\"text-muted\\\">Our products are carefully crafted to support health and overall wellness. Each product represents a strong connection between Mother Nature, dedicated farmers, and our valued customers. We maintain the highest standards of purity &mdash; all products are 100% natural with no preservatives, no additives, and no added sugar.</p>\\n</div>\\n</div>\\n<!-- Directors -->\\n<div class=\\\"row g-4 mb-5\\\">\\n<div class=\\\"col-md-6\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h5 class=\\\"fw-semibold mb-2\\\">Pankaj Sutariya</h5>\\n<p class=\\\"text-muted mb-0\\\">MBA &mdash; London, United Kingdom</p>\\n</div>\\n</div>\\n<div class=\\\"col-md-6\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h5 class=\\\"fw-semibold mb-2\\\">Dharmendrakumar Bhanderi</h5>\\n<ul class=\\\"text-muted mb-0 ps-3\\\">\\n<li>Science &amp; Engineering &mdash; University of Technology Sydney (UTS), Australia</li>\\n<li>Community Welfare Work &mdash; Lamart College of Technology, Sydney</li>\\n<li>Registered Pharmacist &mdash; Gujarat, India</li>\\n</ul>\\n</div>\\n</div>\\n</div>\\n<!-- Company Details -->\\n<div class=\\\"row g-4\\\">\\n<div class=\\\"col-md-6 col-lg-4\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h6 class=\\\"fw-bold\\\">Business Type</h6>\\n<p class=\\\"text-muted mb-0\\\">Manufacturer &amp; Exporter</p>\\n</div>\\n</div>\\n<div class=\\\"col-md-6 col-lg-4\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h6 class=\\\"fw-bold\\\">Year of Establishment</h6>\\n<p class=\\\"text-muted mb-0\\\">2016</p>\\n</div>\\n</div>\\n<div class=\\\"col-md-6 col-lg-4\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h6 class=\\\"fw-bold\\\">Number of Employees</h6>\\n<p class=\\\"text-muted mb-0\\\">30</p>\\n</div>\\n</div>\\n<div class=\\\"col-md-6 col-lg-4\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h6 class=\\\"fw-bold\\\">Production</h6>\\n<p class=\\\"text-muted mb-0\\\">Fully Automatic</p>\\n</div>\\n</div>\\n<div class=\\\"col-md-6 col-lg-4\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h6 class=\\\"fw-bold\\\">Testing Facility</h6>\\n<p class=\\\"text-muted mb-0\\\">Available</p>\\n</div>\\n</div>\\n<div class=\\\"col-md-6 col-lg-4\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm h-100\\\">\\n<h6 class=\\\"fw-bold\\\">Competitive Advantages</h6>\\n<ul class=\\\"text-muted mb-0 ps-3\\\">\\n<li>Customer Satisfaction</li>\\n<li>High Product Quality</li>\\n<li>On-time Delivery</li>\\n<li>Experienced Professionals</li>\\n</ul>\\n</div>\\n</div>\\n</div>\\n<!-- Certifications -->\\n<div class=\\\"row mt-5\\\">\\n<div class=\\\"col-lg-10 mx-auto\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm\\\">\\n<h5 class=\\\"fw-semibold mb-3\\\">Certifications</h5>\\n<div class=\\\"row row-cols-2 row-cols-md-3 g-2 text-muted\\\">\\n<div>✔ FSSAI Certified</div>\\n<div>✔ ISO 22000:2018 Certified</div>\\n<div>✔ US-FDA Registered</div>\\n<div>✔ HACCP Certified</div>\\n<div>✔ Organic Certified</div>\\n<div>✔ WHO-GMP Certified</div>\\n</div>\\n</div>\\n</div>\\n</div>\\n<!-- Products -->\\n<div class=\\\"row mt-4\\\">\\n<div class=\\\"col-lg-10 mx-auto\\\">\\n<div class=\\\"p-4 bg-white rounded shadow-sm\\\">\\n<h5 class=\\\"fw-semibold mb-3\\\">Our Products</h5>\\n<div class=\\\"row row-cols-2 row-cols-md-4 g-2 text-muted\\\">\\n<div>&bull; Food Supplements</div>\\n<div>&bull; Herbal Oil Drops</div>\\n<div>&bull; Herbal Syrup</div>\\n<div>&bull; Organic Vegetables &amp; Herbal Powder</div>\\n</div>\\n</div>\\n</div>\\n</div>\\n</div>\\n</section>\"}]','default','published',NULL,'2026-02-22 17:57:08','2026-02-22 17:57:08',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('12',NULL,'products','Alfalfa Leaves','alfalfa-leaves',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/05e6acf6e10f42b6f70b1acaebd072a7.jpg','2026-02-23 17:14:50','2026-02-23 19:40:05',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('13',NULL,'products','Beet Root','beet-root',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/9d2285351074b20de83bf1624be2b803.jpg','2026-02-23 17:14:50','2026-02-23 19:35:41',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('14',NULL,'products','Bottle Gourd (Lauki) (Dudhi)','bottle-gourd-lauki-dudhi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/08db8c2575219c21f5e91707bb2fe247.jpg','2026-02-23 17:14:50','2026-02-23 19:47:54',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('15',NULL,'products','Coriander Leaves','coriander-leaves',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/f72ea1b581c8b4df247de7337efb66cf.jpg','2026-02-23 17:14:50','2026-02-23 19:49:25',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('16',NULL,'products','Fenugreek Leaves (Kasuri Methi)','fenugreek-leaves-kasuri-methi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/6c166792dc90ddd22f031eee11a2ac31.jpg','2026-02-23 17:14:50','2026-02-23 19:50:17',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('17',NULL,'products','Amla (Indian Gooseberry)','amla-indian-gooseberry',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/2921ab8581739a1f163f0c5f474f01e8.jpg','2026-02-23 17:14:50','2026-02-23 19:44:49',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('18',NULL,'products','Ginger (Raw Ginger)','ginger-raw-ginger',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/ce2a37e81851b73789652cf14619b366.jpg','2026-02-23 17:14:50','2026-02-23 19:50:57',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('19',NULL,'products','Mint Leaves','mint-leaves',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/5c7a0a23a2cf162498646403b228fa34.jpg','2026-02-23 17:14:50','2026-02-23 19:52:06',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('20',NULL,'products','Moringa Leaves','moringa-leaves',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/cca5d7972d8d16c61f4480f12a58e76b.jpg','2026-02-23 17:14:50','2026-02-23 19:53:10',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('21',NULL,'products','Pumpkin','pumpkin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/db80fca2af7e21bff24a254120b0f282.jpg','2026-02-23 17:14:50','2026-02-23 19:53:48',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('22',NULL,'products','Radish','radish',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/dad88d812d417d8c882a26bb57924022.jpg','2026-02-23 17:14:50','2026-02-23 19:56:04',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('23',NULL,'products','Spinach Leaves (Palak)','spinach-leaves-palak',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/3e6711a75ee005b70c76731580447893.jpg','2026-02-23 17:14:50','2026-02-23 19:56:49',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('24',NULL,'products','Wheat Grass','wheat-grass',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/1fe73fdd69d11585cedd3452c75b2ce5.jpg','2026-02-23 17:14:50','2026-02-23 19:59:15',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('25',NULL,'products','Natural Vitamin B-Complex Powder','natural-vitamin-b-complex-powder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/8db886fceae06cc46d20c15af629f7a4.jpg','2026-02-23 17:14:50','2026-02-23 19:39:02',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('26',NULL,'products','1. Natural Vitamin B12 Powder','1-natural-vitamin-b12-powder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/7afc2a8dcdc091edfa42b15a27c8652f.jpg','2026-02-23 17:14:50','2026-02-23 19:32:47',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('27',NULL,'products','Natural Vitamin C Powder','natural-vitamin-c-powder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/0f3d56eda084c7522c1395b5ece429b4.jpg','2026-02-23 17:14:50','2026-02-23 19:37:01',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('28',NULL,'products','Natural Multi-Vitamins Powder','natural-multi-vitamins-powder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/5c80206c061c70f9302bf0020a844c57.jpg','2026-02-23 17:14:50','2026-02-23 19:33:57',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('29',NULL,'products','Bitter Gourd (Karela)','bitter-gourd-karela',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/496e2870b84a6c46be6a5412465bd730.jpg','2026-02-23 17:14:50','2026-02-23 19:46:43',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('30',NULL,'products','Suran (Jimikand)','suran-jimikand',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/8ee4204d565652d0aedbc8302100cac7.jpg','2026-02-23 17:14:50','2026-02-23 19:58:04',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('31',NULL,'products','Barley Grass','barley-grass',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/d5eb2bccf4cc60e940a98cfc9a7d3c53.jpg','2026-02-23 17:14:50','2026-02-23 19:46:05',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('32',NULL,'products','Drumstick (Moringa Pod)','drumstick-moringa-pod',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/1cd4c8ba38263e076d1c3d14cb6132f5.jpg','2026-02-23 17:14:50','2026-02-23 19:49:50',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('33',NULL,'products','Raw Papaya','raw-papaya',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/f7d76ed3ee9bb46638e7edaac59cf041.jpg','2026-02-23 17:14:50','2026-02-23 19:56:24',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('34',NULL,'products','Spirulina','spirulina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/efac6a9557ac5fd1e53edf4714a60de9.jpg','2026-02-23 17:14:50','2026-02-23 19:57:37',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('35',NULL,'products','Tulsi (Holy Basil)','tulsi-holy-basil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"1\"}}]','default','published','/uploads/media/97c10db850a2536e00f01ff9b9f4042c.jpg','2026-02-23 17:14:50','2026-02-23 19:58:36',NULL,NULL,NULL,NULL);
INSERT INTO `pages` VALUES('36',NULL,'products','Turmeric (Raw Turmeric) (Debug Update)','turmeric-raw-turmeric-debug-update',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','[{\"type\":\"__custom_fields\",\"fields\":{\"productdetail\":\"\",\"show_in_product_gallery\":\"0\"}}]','default','published','/uploads/media/DEBUG_UPDATE_1771873356.jpg','2026-02-23 17:14:50','2026-02-23 19:59:45',NULL,NULL,NULL,NULL);


-- Table structure for `permissions`
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `redirects`
DROP TABLE IF EXISTS `redirects`;
CREATE TABLE `redirects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` text DEFAULT NULL,
  `new_url` text DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 301,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `role_permissions`
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `role_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `roles`
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `settings`
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `settings`
INSERT INTO `settings` VALUES('active_theme','greenbs');
INSERT INTO `settings` VALUES('admin_email','');
INSERT INTO `settings` VALUES('breadcrumbs_enabled','1');
INSERT INTO `settings` VALUES('breadcrumbs_home_label','Home');
INSERT INTO `settings` VALUES('breadcrumbs_schema','1');
INSERT INTO `settings` VALUES('breadcrumbs_separator','/');
INSERT INTO `settings` VALUES('breadcrumbs_show_home','1');
INSERT INTO `settings` VALUES('breadcrumbs_type','auto');
INSERT INTO `settings` VALUES('contact_map_embed_url','https://www.google.com/maps/@21.6013388,73.0287206,15z?entry=ttu&g_ep=EgoyMDI2MDIxOC4wIKXMDSoASAFQAw%3D%3D');
INSERT INTO `settings` VALUES('date_format','d-m-Y');
INSERT INTO `settings` VALUES('default_language','en');
INSERT INTO `settings` VALUES('favicon_path','');
INSERT INTO `settings` VALUES('homepage_id','1');
INSERT INTO `settings` VALUES('logo_path','');
INSERT INTO `settings` VALUES('maintenance_allowed_ips','203.192.227.246, 203.192.227.16, 192.168.1.41, 192.168.1.42, 127.0.0.1');
INSERT INTO `settings` VALUES('maintenance_message','We are upgrading our website. Please check back soon.');
INSERT INTO `settings` VALUES('maintenance_mode','0');
INSERT INTO `settings` VALUES('posts_per_page','10');
INSERT INTO `settings` VALUES('show_theme_credit','1');
INSERT INTO `settings` VALUES('sidebar_search_shortcut','Ctrl+Shift+F');
INSERT INTO `settings` VALUES('site_name','Organic Dehydrated Foods Pvt. Ltd. ');
INSERT INTO `settings` VALUES('site_tagline','Dehydrated Vegetable, Herbal and Fruit Products');
INSERT INTO `settings` VALUES('site_url','');
INSERT INTO `settings` VALUES('time_format','H:i');
INSERT INTO `settings` VALUES('timezone','Asia/Kolkata');


-- Table structure for `slider_images`
DROP TABLE IF EXISTS `slider_images`;
CREATE TABLE `slider_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image_path` varchar(255) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for `slider_images`
INSERT INTO `slider_images` VALUES('3','/uploads/slider/d181ea70975f7b16edf759bf61ca171d.jpg','','','0','1','2026-02-22 07:32:12','2026-02-22 07:32:12');
INSERT INTO `slider_images` VALUES('4','/uploads/slider/fc4b24dc66bf968394a4ebd2129a16fe.jpg','','','0','1','2026-02-22 07:32:21','2026-02-22 07:32:21');
INSERT INTO `slider_images` VALUES('5','/uploads/slider/c18d225a929dd2eb26c1276ec4bfe18b.jpg','','','0','1','2026-02-22 07:32:31','2026-02-22 07:32:31');


-- Table structure for `tags`
DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`),
  UNIQUE KEY `idx_tags_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `templates`
DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `content_json` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `templates`
INSERT INTO `templates` VALUES('1','Hero Block','[\r\n{\r\n  \"type\": \"hero_basic\",\r\n  \"data\": {\r\n    \"title\": \"Build Faster Websites\",\r\n    \"subtitle\": \"Lightweight CMS for modern projects\",\r\n    \"cta_text\": \"Get Started\",\r\n    \"cta_link\": \"/contact\"\r\n  }\r\n}\r\n]','2026-02-19 19:28:30');
INSERT INTO `templates` VALUES('2','Content Block','[\r\n{\r\n  \"type\": \"text_content\",\r\n  \"data\": {\r\n    \"title\": \"About Our Company\",\r\n    \"text\": \"We deliver innovative engineering solutions worldwide.\"\r\n  }\r\n}\r\n]','2026-02-19 19:29:15');
INSERT INTO `templates` VALUES('3','Rich Content Block ','[{\r\n  \"type\": \"rich_content\",\r\n  \"data\": {\r\n    \"html\": \"<p><strong>Custom HTML</strong> from editor</p>\"\r\n  }\r\n}\r\n]','2026-02-19 19:29:37');
INSERT INTO `templates` VALUES('4','Feature / Service Block ','[{\r\n  \"type\": \"features_grid\",\r\n  \"data\": {\r\n    \"title\": \"Our Strengths\",\r\n    \"items\": [\r\n      { \"title\": \"Quality\", \"text\": \"Built to last\" },\r\n      { \"title\": \"Speed\", \"text\": \"Fast delivery\" },\r\n      { \"title\": \"Expert Team\", \"text\": \"Top engineers\" }\r\n    ]\r\n  }\r\n}\r\n]','2026-02-19 19:29:58');
INSERT INTO `templates` VALUES('5','Media Block ','[{\r\n  \"type\": \"image\",\r\n  \"data\": {\r\n    \"src\": \"/media/project.jpg\",\r\n    \"alt\": \"Project image\",\r\n    \"caption\": \"Completed project\"\r\n  }\r\n}\r\n]','2026-02-19 19:30:20');
INSERT INTO `templates` VALUES('6','Gallery Block','[{\r\n  \"type\": \"gallery\",\r\n  \"data\": {\r\n    \"images\": [\r\n      \"/media/g1.jpg\",\r\n      \"/media/g2.jpg\",\r\n      \"/media/g3.jpg\"\r\n    ]\r\n  }\r\n}\r\n]','2026-02-19 19:30:40');
INSERT INTO `templates` VALUES('7','cta block','[{\r\n  \"type\": \"cta_box\",\r\n  \"data\": {\r\n    \"title\": \"Need a custom website?\",\r\n    \"text\": \"Contact our team today.\",\r\n    \"button_text\": \"Contact Us\",\r\n    \"button_link\": \"/contact\"\r\n  }\r\n}\r\n]','2026-02-19 19:31:03');
INSERT INTO `templates` VALUES('8','testimonial Blcik','[{\r\n  \"type\": \"testimonials\",\r\n  \"data\": {\r\n    \"title\": \"What Clients Say\",\r\n    \"items\": [\r\n      {\r\n        \"name\": \"John Smith\",\r\n        \"text\": \"Outstanding service!\"\r\n      }\r\n    ]\r\n  }\r\n}\r\n\r\n]','2026-02-19 19:31:21');
INSERT INTO `templates` VALUES('9','Team Block ','[{\r\n  \"type\": \"team_grid\",\r\n  \"data\": {\r\n    \"title\": \"Our Team\",\r\n    \"members\": [\r\n      {\r\n        \"name\": \"Jane Doe\",\r\n        \"role\": \"CEO\",\r\n        \"photo\": \"/media/jane.jpg\"\r\n      }\r\n    ]\r\n  }\r\n}\r\n]','2026-02-19 19:31:38');
INSERT INTO `templates` VALUES('10','contact Block ','[{\r\n  \"type\": \"contact_info\",\r\n  \"data\": {\r\n    \"address\": \"Mumbai, India\",\r\n    \"phone\": \"+91 99999 99999\",\r\n    \"email\": \"info@example.com\"\r\n  }\r\n}\r\n]','2026-02-19 19:31:57');
INSERT INTO `templates` VALUES('11','Two Column Layout Block','[{\r\n  \"type\": \"two_columns\",\r\n  \"data\": {\r\n    \"left\": \"HTML or nested blocks\",\r\n    \"right\": \"HTML or nested blocks\"\r\n  }\r\n}\r\n]','2026-02-19 19:32:22');
INSERT INTO `templates` VALUES('12','Spacer Block','[{\r\n  \"type\": \"spacer\",\r\n  \"data\": {\r\n    \"height\": \"60px\"\r\n  }\r\n}\r\n]','2026-02-19 19:32:42');
INSERT INTO `templates` VALUES('13','Slider Banner Block','[\r\n{\r\n  \"type\": \"banner_slider\",\r\n  \"data\": {\r\n    \"autoplay\": true,\r\n    \"interval\": 5000,\r\n    \"slides\": [\r\n      {\r\n        \"image\": \"/uploads/slide1.jpg\",\r\n        \"title\": \"Engineering Excellence\",\r\n        \"subtitle\": \"Building the future\",\r\n        \"button_text\": \"Our Services\",\r\n        \"button_link\": \"/services\"\r\n      },\r\n      {\r\n        \"image\": \"/uploads/slide2.jpg\",\r\n        \"title\": \"Innovative Solutions\",\r\n        \"subtitle\": \"Smart infrastructure\",\r\n        \"button_text\": \"Contact Us\",\r\n        \"button_link\": \"/contact\"\r\n      }\r\n    ]\r\n  }\r\n}\r\n]','2026-02-20 15:16:23');


-- Table structure for `user_roles`
DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_roles_role_id_foreign` (`role_id`),
  CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Table structure for `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for `users`
INSERT INTO `users` VALUES('1',NULL,'vittixcom@gmail.com','$2y$10$1maJgwX27LhZ2fLat/cZY.tOZmnC14pxwhNwyf3J6FC3jypZJRxtW','2026-02-19 18:11:44','2026-02-22 18:20:14');

