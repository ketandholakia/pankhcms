<div class="bg-dark text-light py-2 small">
    <div class="container d-flex justify-content-between flex-wrap gap-2">
        <span>{{ setting('site_name', 'PankhCMS') }}</span>
        <span>{{ setting('site_tagline', setting('tagline', '')) }}</span>
    </div>
</div>
