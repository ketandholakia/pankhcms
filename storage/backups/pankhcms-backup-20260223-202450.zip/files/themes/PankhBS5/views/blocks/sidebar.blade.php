<aside class="card border-0 shadow-sm">
    <div class="card-body">
        <h3 class="h6">Quick Links</h3>
        <ul class="list-unstyled mb-0">
            <li><a href="/">Home</a></li>
            <li><a href="/contact">Contact</a></li>
        </ul>
    </div>
</aside>
