@extends('layouts.main')

@section('content')
    <div class="container py-4">
        @yield('boxed_content')
    </div>
@endsection
