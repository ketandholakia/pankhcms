<section class="py-4">
    <div class="container">
        <h2>{{ $block['data']['title'] ?? '' }}</h2>
        <p>{{ $block['data']['text'] ?? '' }}</p>
    </div>
</section>
