<div style="display: flex; justify-content: center; align-items: center; height: 150px;">
    <img src="{{ theme_asset('img/logo.png') }}" alt="Logo" style="max-height: 150px;">
</div>