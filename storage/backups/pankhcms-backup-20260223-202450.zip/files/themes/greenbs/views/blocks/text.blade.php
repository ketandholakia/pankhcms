<section class="py-4">
    <div class="container">
        {!! $block['html'] ?? ($block['data']['text'] ?? '') !!}
    </div>
</section>
