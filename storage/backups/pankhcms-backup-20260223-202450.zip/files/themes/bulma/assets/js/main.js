// Main JS for Bulma theme
