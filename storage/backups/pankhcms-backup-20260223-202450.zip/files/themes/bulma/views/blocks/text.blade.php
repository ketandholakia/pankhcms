<article class="box content">
    {!! $block['html'] ?? '' !!}
</article>
