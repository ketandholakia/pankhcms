<div class="box">
    <p class="title is-6 mb-3">About This Theme</p>
    <p class="is-size-7">This is a minimal Bulma-based layout with hero, content, sidebar, and CTA sections.</p>
</div>

<div class="box">
    <p class="title is-6 mb-3">Navigation</p>
    {!! render_menu('header') !!}
</div>
