<header class="site-header">
  <div class="container header-inner">
    <div class="logo">{{ $site_name ?? 'Site Name' }}</div>
    @include('blocks.menu')
  </div>
</header>
