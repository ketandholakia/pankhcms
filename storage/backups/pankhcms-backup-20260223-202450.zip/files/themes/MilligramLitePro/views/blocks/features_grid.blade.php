<section class="features">
  <div class="row">
    <div class="column">
      <h4>Quality</h4>
      <p>Premium standards</p>
    </div>
    <div class="column">
      <h4>Organic</h4>
      <p>Natural ingredients</p>
    </div>
    <div class="column">
      <h4>Certified</h4>
      <p>Trusted globally</p>
    </div>
  </div>
</section>
