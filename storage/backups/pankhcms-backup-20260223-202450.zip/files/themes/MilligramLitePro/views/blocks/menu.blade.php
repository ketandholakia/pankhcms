<nav>
  <a href="/">Home</a>
  <a href="/page">About</a>
  <a href="/product">Products</a>
  <a href="/contact">Contact</a>
</nav>
