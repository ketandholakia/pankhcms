<section class="products">
  <h2>Products</h2>

  <div class="row">
    <div class="column">
      <h5>Product 1</h5>
      <p>Description</p>
    </div>
    <div class="column">
      <h5>Product 2</h5>
      <p>Description</p>
    </div>
    <div class="column">
      <h5>Product 3</h5>
      <p>Description</p>
    </div>
  </div>
</section>
