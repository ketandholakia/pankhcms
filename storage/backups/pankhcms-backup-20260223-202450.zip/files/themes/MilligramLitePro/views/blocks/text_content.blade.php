<section>
  {!! $content ?? '' !!}
</section>
