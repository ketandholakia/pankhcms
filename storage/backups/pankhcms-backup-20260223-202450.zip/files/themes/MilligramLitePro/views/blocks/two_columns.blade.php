<div class="row">
  <div class="column">
    {!! $left ?? '' !!}
  </div>
  <div class="column">
    {!! $right ?? '' !!}
  </div>
</div>
