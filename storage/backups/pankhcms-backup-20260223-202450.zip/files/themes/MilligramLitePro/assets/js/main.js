document.addEventListener("DOMContentLoaded", function () {
  console.log("MilligramLite Pro Loaded");
});
