<nav>
	<a href="/">Home</a>
	<a href="/page">Page</a>
	<a href="/contact">Contact</a>
</nav>
