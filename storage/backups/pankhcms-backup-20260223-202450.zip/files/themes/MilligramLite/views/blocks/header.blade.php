<header class="site-header">
    <div class="container">
        <h3>{{ $site_name ?? 'Site Name' }}</h3>
        @include('blocks.menu')
    </div>
</header>