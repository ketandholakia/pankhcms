<footer class="site-footer">
    <div class="container">
        <p>&copy; {{ date('Y') }} {{ $site_name ?? 'Site Name' }}</p>
    </div>
</footer>