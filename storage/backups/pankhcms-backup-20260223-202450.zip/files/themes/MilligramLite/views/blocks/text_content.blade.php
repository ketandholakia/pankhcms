<section>
    {!! $content ?? '' !!}
</section>
<section>
    {!! $content ?? '' !!}
</section>