<section class="hero">
    <h1>{{ $title ?? 'Welcome' }}</h1>
    <p>{{ $subtitle ?? '' }}</p>
</section>
<section class="hero">
    <h1>{{ $title ?? 'Welcome' }}</h1>
    <p>{{ $subtitle ?? '' }}</p>
</section>