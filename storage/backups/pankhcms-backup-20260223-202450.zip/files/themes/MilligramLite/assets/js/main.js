document.addEventListener("DOMContentLoaded", function () {
  console.log("MilligramLite theme ready");
});