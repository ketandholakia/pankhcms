/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './views/**/*.blade.php',
    '../../views/**/*.blade.php'
  ],
  theme: {
    extend: {}
  },
  plugins: []
};
