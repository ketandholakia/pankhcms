@extends('templates.product')
