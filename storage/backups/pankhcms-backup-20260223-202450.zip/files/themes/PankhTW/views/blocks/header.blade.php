<header class="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur">
    <div class="pankh-container flex items-center justify-between py-3">
        <a href="/" class="text-lg font-semibold tracking-tight text-slate-900">{{ setting('site_name', 'PankhCMS') }}</a>
        <div>
            {!! render_menu('header') !!}
        </div>
    </div>
</header>
