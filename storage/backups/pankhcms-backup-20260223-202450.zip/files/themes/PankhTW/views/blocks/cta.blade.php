@include(theme_view('blocks.cta_box'), ['block' => $block ?? []])
