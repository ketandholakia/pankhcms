<section class="pankh-card p-5">
    <h3 class="text-lg font-semibold">Contact Information</h3>
    <div class="mt-3 space-y-1 text-sm text-slate-600">
        <p>{{ setting('site_name', 'PankhCMS') }}</p>
        <p>{{ setting('site_tagline', setting('tagline', '')) }}</p>
    </div>
</section>
