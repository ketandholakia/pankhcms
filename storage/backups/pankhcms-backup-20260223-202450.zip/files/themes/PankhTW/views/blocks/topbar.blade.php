<div class="border-b border-slate-200 bg-white">
    <div class="pankh-container flex flex-wrap items-center justify-between gap-2 py-2 text-xs text-slate-600">
        <span>{{ setting('site_name', 'PankhCMS') }}</span>
        <span>{{ setting('site_tagline', setting('tagline', '')) }}</span>
    </div>
</div>
