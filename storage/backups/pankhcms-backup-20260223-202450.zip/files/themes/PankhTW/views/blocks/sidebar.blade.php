<aside class="pankh-card p-5">
    <h3 class="text-base font-semibold">Quick Links</h3>
    <ul class="mt-3 space-y-2 text-sm">
        <li><a href="/" class="text-slate-600 hover:text-slate-900">Home</a></li>
        <li><a href="/contact" class="text-slate-600 hover:text-slate-900">Contact</a></li>
    </ul>
</aside>
