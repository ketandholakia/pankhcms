@extends('layouts.main')

@section('content')
    @include(theme_view('site.contact'))
@endsection
