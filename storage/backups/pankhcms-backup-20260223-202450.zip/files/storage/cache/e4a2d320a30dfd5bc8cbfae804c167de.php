<div style="display: flex; justify-content: center; align-items: center; height: 150px;">
    <img src="<?php echo e(theme_asset('img/logo.png')); ?>" alt="Logo" style="max-height: 150px;">
</div><?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/topbar.blade.php ENDPATH**/ ?>