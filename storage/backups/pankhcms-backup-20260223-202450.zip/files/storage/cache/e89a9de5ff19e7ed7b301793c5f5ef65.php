    <?php ($currentPage = $page ?? null); ?>

<title><?php echo e(seo_title($currentPage)); ?></title>
<meta name="description" content="<?php echo e(seo_description($currentPage)); ?>">
<meta name="keywords" content="<?php echo e(seo_keywords($currentPage)); ?>">

<?php ($favicon = seo_setting('favicon', 'logo_path', '')); ?>
<?php if($favicon): ?>
    <link rel="icon" href="<?php echo e(seo_absolute_url($favicon)); ?>">
<?php endif; ?>

<link rel="canonical" href="<?php echo e(canonical_url($currentPage)); ?>">
<meta name="robots" content="<?php echo e(seo_robots($currentPage)); ?>">

<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo e(seo_title($currentPage)); ?>">
<meta property="og:description" content="<?php echo e(seo_description($currentPage)); ?>">
<meta property="og:image" content="<?php echo e(seo_image($currentPage)); ?>">
<meta property="og:url" content="<?php echo e(canonical_url($currentPage)); ?>">
<meta property="og:site_name" content="<?php echo e(seo_site_title()); ?>">

<meta name="twitter:card" content="<?php echo e(seo_twitter_card($currentPage)); ?>">
<meta name="twitter:title" content="<?php echo e(seo_title($currentPage)); ?>">
<meta name="twitter:description" content="<?php echo e(seo_description($currentPage)); ?>">
<meta name="twitter:image" content="<?php echo e(seo_image($currentPage)); ?>">

<?php if(!empty($breadcrumbs)): ?>
    <?php echo breadcrumbSchema($breadcrumbs); ?>

<?php endif; ?><?php /**PATH /shared/httpd/pankhCMS/views/partials/seo.blade.php ENDPATH**/ ?>