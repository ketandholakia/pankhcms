<?php
use App\Models\SliderImage;
$sliderImages = SliderImage::where('active', 1)->orderBy('sort_order')->get();
?>
<?php if($sliderImages->count()): ?>
<style>
    #header-carousel img {
        max-height: 340px;
        object-fit: cover;
    }
    @media (max-width: 600px) {
        #header-carousel img { max-height: 180px; }
    }
</style>
<div class="container-fluid p-0">
    <div id="header-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php $__currentLoopData = $sliderImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php if($i === 0): ?> active <?php endif; ?>">
                    <img class="w-100" src="<?php echo e($slide->image_path); ?>" alt="<?php echo e($slide->caption); ?>">
                    <?php if($slide->caption || $slide->link): ?>
                        <div class="carousel-caption top-0 bottom-0 start-0 end-0 d-flex flex-column align-items-center justify-content-center">
                            <div class="text-start p-5" style="max-width: 900px;">
                                <?php if($slide->caption): ?>
                                    <h3 class="text-white"><?php echo e($slide->caption); ?></h3>
                                <?php endif; ?>
                                <?php if($slide->link): ?>
                                    <a href="<?php echo e($slide->link); ?>" class="btn btn-primary py-md-3 px-md-5 me-3" target="_blank">Learn More</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        <div class="carousel-indicators">
            <?php $__currentLoopData = $sliderImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#header-carousel" data-bs-slide-to="<?php echo e($i); ?>" class="<?php if($i === 0): ?> active <?php endif; ?>" aria-current="<?php if($i === 0): ?> true <?php endif; ?>" aria-label="Slide <?php echo e($i+1); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /shared/httpd/pankhCMS/themes/greenbs/views/blocks/slider_bootstrap.blade.php ENDPATH**/ ?>