<section class="card text-center">

  <h2>{{ $cta['title'] }}</h2>

  <p>{{ $cta['text'] }}</p>

  <a href="{{ $cta['url'] }}" class="btn btn-secondary">
    {{ $cta['button'] }}
  </a>

</section>
