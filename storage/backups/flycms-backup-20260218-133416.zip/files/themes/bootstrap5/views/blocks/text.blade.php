<article class="card shadow-sm border-0 mb-3">
    <div class="card-body content-html">
        {!! $block['html'] ?? '' !!}
    </div>
</article>
