<section class="block block-text">
    <?php echo $block['html'] ?? ''; ?>

</section>
<?php /**PATH /shared/httpd/flyCMS/themes/default/views/blocks/text.blade.php ENDPATH**/ ?>