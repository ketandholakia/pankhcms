<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  

  <title><?php echo e(($page->meta_title ?? null) ?: ($title ?? ($site_title ?? ($seo_default_title ?? 'flyCMS')))); ?></title>

  <meta name="description"
        content="<?php echo e(($page->meta_description ?? null) ?: ($seo_default_description ?? '')); ?>">

  <meta name="keywords"
        content="<?php echo e(($page->meta_keywords ?? null) ?: ($seo_default_keywords ?? '')); ?>">

  
  <meta property="og:title"
        content="<?php echo e(($page->og_title ?? null) ?: ($og_title_default ?? ($seo_default_title ?? $site_title ?? 'flyCMS'))); ?>">

  <meta property="og:description"
        content="<?php echo e(($page->og_description ?? null) ?: ($og_description_default ?? ($seo_default_description ?? $site_description ?? ''))); ?>">

  <meta property="og:image"
        content="<?php echo e(($page->og_image ?? null) ?: ($og_image_default ?? '')); ?>">

  <meta property="og:url"
        content="<?php echo e(($page->canonical_url ?? null) ?: ($canonical_base ?? env('APP_URL') . \Flight::request()->url)); ?>">

  <meta property="og:type" content="website">

  
  <link rel="canonical"
        href="<?php echo e(($page->canonical_url ?? null) ?: ($canonical_base ?? env('APP_URL') . \Flight::request()->url)); ?>">

  
  <meta name="robots"
        content="<?php echo e(($page->robots ?? null) ?: ($robots_default ?? 'index, follow')); ?>">

  
  <meta name="twitter:card"
        content="<?php echo e(($page->twitter_card ?? null) ?: ($twitter_card ?? 'summary_large_image')); ?>">

  <meta name="twitter:site"
        content="<?php echo e(($page->twitter_site ?? null) ?: ($twitter_site ?? '')); ?>">

  <meta name="twitter:title"
        content="<?php echo e(($page->og_title ?? null) ?: ($og_title_default ?? ($seo_default_title ?? $site_title ?? 'flyCMS'))); ?>">

  <meta name="twitter:description"
        content="<?php echo e(($page->og_description ?? null) ?: ($og_description_default ?? ($seo_default_description ?? $site_description ?? ''))); ?>">

  <meta name="twitter:image"
        content="<?php echo e(($page->og_image ?? null) ?: ($og_image_default ?? '')); ?>">

  

  <link rel="stylesheet"
        href="<?php echo e(\App\Core\Theme::asset('css/flywind-core.css')); ?>">

  <link rel="stylesheet"
        href="<?php echo e(\App\Core\Theme::asset('css/custom.css')); ?>">

</head>


<body>



<header class="site-header">

  <div class="container nav">

    <a href="/" class="site-logo">
      <?php echo e($site_title ?? 'flyCMS'); ?>

    </a>

    <button id="nav-toggle"
            class="nav-toggle"
            aria-label="Toggle navigation"
            aria-expanded="false">
      ☰
    </button>

    <nav class="main-nav">
      <?php
        $menuTree = menu_tree('navbar');
        if (empty($menuTree)) {
            $menuTree = menu_tree('header');
        }
      ?>
      <?php echo $__env->make('blocks.menu', ['tree' => $menuTree], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </nav>

  </div>

</header>




<?php if(setting('breadcrumbs_enabled') === '1' && !empty($breadcrumbs)): ?>

  <nav class="breadcrumb container" aria-label="breadcrumbs">

    <ul>

      <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['is-active' => $loop->last]); ?>">

          <?php if(!$loop->last): ?>
            <a href="<?php echo e($crumb['url']); ?>"><?php echo e($crumb['title']); ?></a>
          <?php else: ?>
            <span><?php echo e($crumb['title']); ?></span>
          <?php endif; ?>

        </li>

        <?php if(!$loop->last): ?>
          <span class="breadcrumb-separator">
            <?php echo e(setting('breadcrumbs_separator', '/')); ?>

          </span>
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

  </nav>

  <?php if(setting('breadcrumbs_schema') === '1'): ?>
    <?php echo breadcrumbSchema($breadcrumbs); ?>

  <?php endif; ?>

<?php endif; ?>




<?php if(isset($hero)): ?>
  <?php echo $__env->make('blocks.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>




<main class="container layout mt-2">

  <section>
    <?php echo $__env->yieldContent('content'); ?>
  </section>

  <?php echo $__env->make('blocks.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</main>




<footer class="site-footer">

  <div class="container">
    © <?php echo e(date('Y')); ?> <?php echo e($site_title ?? 'flyCMS'); ?>

  </div>

</footer>




<script>

document.addEventListener('DOMContentLoaded', function () {

  const toggle = document.getElementById('nav-toggle');
  const nav = document.querySelector('.main-nav');

  if (!toggle || !nav) return;

  toggle.addEventListener('click', function () {

    nav.classList.toggle('open');

    const isOpen = nav.classList.contains('open');
    toggle.setAttribute('aria-expanded', isOpen);

  });

});

</script>

</body>
</html>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/default/views/layouts/site.blade.php ENDPATH**/ ?>