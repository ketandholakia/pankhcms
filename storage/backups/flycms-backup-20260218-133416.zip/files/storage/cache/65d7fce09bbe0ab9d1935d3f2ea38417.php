<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-6">
    <h1 class="text-2xl font-bold mb-4">
        Search results for "<?php echo e($q); ?>"
    </h1>

    <?php if($q === ''): ?>
        <p>Please enter a search term.</p>
    <?php elseif($pages->isEmpty()): ?>
        <p>No results found.</p>
    <?php else: ?>
        <ul class="space-y-4">
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="/<?php echo e($p->slug); ?>" class="text-blue-600 text-lg font-semibold">
                        <?php echo e($p->title); ?>

                    </a>

                    <p class="text-gray-600">
                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($p->content ?? ''), 150)); ?>

                    </p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/flyCMS/views/site/search.blade.php ENDPATH**/ ?>