<?php $__env->startSection('content'); ?>

<article class="content card">

  <h1><?php echo e($page['title']); ?></h1>

  <?php echo $page['content']; ?>


</article>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/flywind/views/page.blade.php ENDPATH**/ ?>