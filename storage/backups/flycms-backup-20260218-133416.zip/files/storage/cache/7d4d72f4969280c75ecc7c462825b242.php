<section class="py-5 text-white hero-gradient">
    <div class="container py-4">
        <h1 class="display-5 fw-bold mb-2"><?php echo e($page->title ?? 'Welcome'); ?></h1>
        <?php if(!empty($page->meta_description)): ?>
            <p class="lead mb-0"><?php echo e($page->meta_description); ?></p>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /shared/httpd/flyCMS/themes/bootstrap5/views/blocks/hero.blade.php ENDPATH**/ ?>