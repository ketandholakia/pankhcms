<aside>

  <div class="card widget">
    <div class="widget-title">About</div>
    <p><?php echo e($site_description ?? ''); ?></p>
  </div>

  <?php $__currentLoopData = ($widgets ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card widget">
      <div class="widget-title">
        <?php echo e($widget['title']); ?>

      </div>

      <?php echo $widget['content']; ?>

    </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</aside>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/default/views/blocks/sidebar.blade.php ENDPATH**/ ?>