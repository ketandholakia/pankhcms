<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
  <title><?php echo e(($page->meta_title ?? null) ?: ($title ?? ($site_title ?? ($seo_default_title ?? 'flyCMS')))); ?></title>
  <meta name="description" content="<?php echo e(($page->meta_description ?? null) ?: ($seo_default_description ?? '')); ?>">
  <meta name="keywords" content="<?php echo e(($page->meta_keywords ?? null) ?: ($seo_default_keywords ?? '')); ?>">

  <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/flywind-core.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/custom.css')); ?>">
</head>

<body>

<header class="site-header">
  <div class="container nav">

    <strong><?php echo e($site_title ?? 'flyCMS'); ?></strong>

    <?php echo $__env->make('blocks.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  </div>
</header>


<?php if(isset($hero)): ?>
  <?php echo $__env->make('blocks.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<main class="container layout mt-2">

  <section>
    <?php echo $__env->yieldContent('content'); ?>
  </section>

  <?php echo $__env->make('blocks.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</main>

<footer class="site-footer">
  <div class="container">
    © <?php echo e(date('Y')); ?> <?php echo e($site_title ?? 'flyCMS'); ?>

  </div>
</footer>

</body>
</html>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/flywind/views/layouts/site.blade.php ENDPATH**/ ?>