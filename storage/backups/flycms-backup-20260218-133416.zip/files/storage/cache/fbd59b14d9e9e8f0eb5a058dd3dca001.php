<article class="box content">
    <?php echo $block['html'] ?? ''; ?>

</article>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/bulma/views/blocks/text.blade.php ENDPATH**/ ?>