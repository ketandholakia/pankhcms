<?php
    use App\Models\Page;
?>

<?php if(count($tree)): ?>
    <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $itemUrl = $item->page_id ? '/' . optional(Page::find($item->page_id))->slug : ($item->url ?: '#');
            $hasChildren = !empty($item->children);
            $dropdownId = 'menuDropdown' . $item->id;
        ?>

        <?php if($hasChildren): ?>
            <div class="nav-item dropdown">
                <div class="d-flex align-items-center">
                    <a class="nav-link" href="<?php echo e($itemUrl); ?>"><?php echo e($item->title); ?></a>
                    <a class="nav-link dropdown-toggle" href="#" id="<?php echo e($dropdownId); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false"></a>
                </div>

                <ul class="dropdown-menu" aria-labelledby="<?php echo e($dropdownId); ?>">
                    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $childUrl = $child->page_id ? '/' . optional(Page::find($child->page_id))->slug : ($child->url ?: '#');
                        ?>
                        <li>
                            <a class="dropdown-item" href="<?php echo e($childUrl); ?>">
                                <?php echo e($child->title); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php else: ?>
            <a class="nav-link" href="<?php echo e($itemUrl); ?>">
                <?php echo e($item->title); ?>

            </a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /shared/httpd/flyCMS/themes/bootstrap5/views/site/menu.blade.php ENDPATH**/ ?>