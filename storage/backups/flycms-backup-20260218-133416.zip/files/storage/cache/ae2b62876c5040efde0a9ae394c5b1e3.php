<?php
    use App\Models\Page;
?>

<?php if(count($tree)): ?>
<ul class="theme-menu-list">
    <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $itemUrl = $item->page_id ? '/' . optional(Page::find($item->page_id))->slug : ($item->url ?: '#');
            $hasChildren = !empty($item->children);
        ?>
        <li class="theme-menu-item<?php echo e($hasChildren ? ' has-children' : ''); ?>">
            <div class="theme-menu-head">
                <a href="<?php echo e($itemUrl); ?>" class="theme-menu-link">
                    <?php echo e($item->title); ?>

                    <?php if($hasChildren): ?>
                        <span class="theme-menu-caret">
                            <svg width="12" height="12" viewBox="0 0 24 24"><path fill="currentColor" d="M7 10l5 5 5-5z"/></svg>
                        </span>
                    <?php endif; ?>
                </a>
                <?php if($hasChildren): ?>
                    <button type="button" class="theme-menu-toggle" aria-expanded="false" aria-label="Toggle submenu">▾</button>
                <?php endif; ?>
            </div>
            <?php if($hasChildren): ?>
                <ul class="theme-submenu">
                    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $childUrl = $child->page_id ? '/' . optional(Page::find($child->page_id))->slug : ($child->url ?: '#');
                        ?>
                        <li><a href="<?php echo e($childUrl); ?>" class="theme-submenu-link"><?php echo e($child->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/bulma/views/site/menu.blade.php ENDPATH**/ ?>