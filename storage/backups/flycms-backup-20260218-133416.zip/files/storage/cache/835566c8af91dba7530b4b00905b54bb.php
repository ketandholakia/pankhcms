<?php if(!empty($tree) && count($tree)): ?>
<ul>
  <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $href = $item->page_id ? '/' . optional(App\Models\Page::find($item->page_id))->slug : $item->url;
      $hasChildren = !empty($item->children) && count($item->children) > 0;
    ?>
    <li>
      <a href="<?php echo e($href); ?>"><?php echo e($item->title); ?></a>
      <?php if($hasChildren): ?>
        <?php echo $__env->make('blocks.menu', ['tree' => $item->children], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <?php endif; ?>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/default/views/blocks/menu.blade.php ENDPATH**/ ?>