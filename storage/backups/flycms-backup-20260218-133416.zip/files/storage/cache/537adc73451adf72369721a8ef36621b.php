<?php if(count($tree)): ?>
<ul>
    <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e($item->page_id ? '/' . optional(App\Models\Page::find($item->page_id))->slug : $item->url); ?>" class="hover:underline">
                <?php echo e($item->title); ?>

            </a>
            <?php if(!empty($item->children)): ?>
                <ul class="ml-4">
                    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e($child->page_id ? '/' . optional(App\Models\Page::find($child->page_id))->slug : $child->url); ?>" class="hover:underline">
                                <?php echo e($child->title); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<?php /**PATH /shared/httpd/flyCMS/views/site/menu.blade.php ENDPATH**/ ?>