<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Theme Settings</h1>

    <?php if(isset($_GET['status']) && $_GET['status'] === 'updated'): ?>
        <div class="mb-4 rounded border border-green-300 bg-green-50 text-green-800 px-4 py-2">
            Active theme updated successfully.
        </div>
    <?php endif; ?>

    <?php if(isset($_GET['status']) && $_GET['status'] === 'invalid'): ?>
        <div class="mb-4 rounded border border-red-300 bg-red-50 text-red-800 px-4 py-2">
            Selected theme is invalid.
        </div>
    <?php endif; ?>

    <?php if(isset($_GET['status']) && $_GET['status'] === 'settings-missing'): ?>
        <div class="mb-4 rounded border border-red-300 bg-red-50 text-red-800 px-4 py-2">
            Settings table not found. Please create the settings table first.
        </div>
    <?php endif; ?>

    <?php if(empty($themes)): ?>
        <div class="rounded border border-yellow-300 bg-yellow-50 text-yellow-800 px-4 py-3">
            No themes found in the themes folder.
        </div>
    <?php else: ?>
        <form method="POST" action="/admin/themes" class="bg-white border rounded-lg p-4">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2" for="theme">Active Theme</label>
                <select name="theme" id="theme" class="w-full border rounded px-3 py-2">
                    <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($theme['slug']); ?>" <?php echo e($activeTheme === $theme['slug'] ? 'selected' : ''); ?>>
                            <?php echo e($theme['name']); ?> (<?php echo e($theme['slug']); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded">
                Save Theme
            </button>
        </form>

        <div class="mt-6 bg-white border rounded-lg overflow-hidden">
            <table class="min-w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="text-left px-4 py-2 border-b">Name</th>
                        <th class="text-left px-4 py-2 border-b">Slug</th>
                        <th class="text-left px-4 py-2 border-b">Version</th>
                        <th class="text-left px-4 py-2 border-b">Author</th>
                        <th class="text-left px-4 py-2 border-b">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($activeTheme === $theme['slug'] ? 'bg-blue-50' : ''); ?>">
                            <td class="px-4 py-2 border-b"><?php echo e($theme['name']); ?></td>
                            <td class="px-4 py-2 border-b"><?php echo e($theme['slug']); ?></td>
                            <td class="px-4 py-2 border-b"><?php echo e($theme['version']); ?></td>
                            <td class="px-4 py-2 border-b"><?php echo e($theme['author']); ?></td>
                            <td class="px-4 py-2 border-b"><?php echo e($theme['description']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/flyCMS/views/admin/themes/index.blade.php ENDPATH**/ ?>