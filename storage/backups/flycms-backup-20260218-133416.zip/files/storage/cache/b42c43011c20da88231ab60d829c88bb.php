<div class="box">
    <p class="title is-6 mb-3">About This Theme</p>
    <p class="is-size-7">This is a minimal Bulma-based layout with hero, content, sidebar, and CTA sections.</p>
</div>

<div class="box">
    <p class="title is-6 mb-3">Navigation</p>
    <?php echo render_menu('header'); ?>

</div>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/bulma/views/blocks/sidebar.blade.php ENDPATH**/ ?>