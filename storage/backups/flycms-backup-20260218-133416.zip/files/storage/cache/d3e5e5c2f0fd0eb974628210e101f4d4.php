<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('blocks.hero', ['page' => $page], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section py-5">
        <div class="container">
            <div class="columns is-variable is-6">
                <div class="column is-two-thirds">
                    <?php if(!empty($blocks)): ?>
                        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if ($__env->exists('blocks.' . ($block['type'] ?? ''), ['block' => $block])) echo $__env->make('blocks.' . ($block['type'] ?? ''), ['block' => $block], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="box">
                            <p>No blocks yet for this page.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="column is-one-third">
                    <?php echo $__env->make('blocks.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('blocks.cta', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/bulma/views/page.blade.php ENDPATH**/ ?>