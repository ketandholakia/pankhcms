<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-2xl font-bold mb-4">Menus</h1>

    <div id="menu-notice" class="fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded shadow hidden"></div>

    <!-- Create Menu -->
    <div class="mb-6 bg-white p-4 rounded shadow border border-gray-200">
        <h2 class="text-lg font-bold mb-2">Create Menu</h2>
        <form id="menu-create-form" class="grid grid-cols-1 md:grid-cols-2 gap-2">
            <div>
                <label class="block mb-1 font-semibold">Menu Name</label>
                <input class="w-full border px-3 py-2 rounded" type="text" name="name" required>
            </div>
            <div>
                <label class="block mb-1 font-semibold">Location</label>
                <input class="w-full border px-3 py-2 rounded" type="text" name="location" required>
            </div>
            <div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Create</button>
            </div>
        </form>
    </div>

    <!-- Menu Selector & Edit -->
    <form method="GET" class="mb-6 inline-block">
        <label class="font-semibold mr-2">Select Menu:</label>
        <select name="menu_id" class="border px-2 py-1 rounded" onchange="this.form.submit()">
            <option value="">-- Choose --</option>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($menu->id); ?>" <?php if(isset($selectedMenu) && $selectedMenu && $selectedMenu->id == $menu->id): ?> selected <?php endif; ?>><?php echo e($menu->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>
    <?php if(isset($selectedMenu) && $selectedMenu): ?>
    <button onclick="openMenuEditModal()" class="ml-4 bg-yellow-400 text-white px-3 py-1 rounded">Edit Menu</button>
    <form action="/admin/menus/<?php echo e($selectedMenu->id); ?>/delete" method="POST" class="inline js-menu-delete" onsubmit="return confirm('Delete this menu?');">
        <button type="submit" class="ml-2 bg-red-600 text-white px-3 py-1 rounded">Delete Menu</button>
    </form>
    <?php endif; ?>

    <!-- Edit Menu Modal -->
    <div id="menu-edit-modal" class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden">
        <div class="bg-white p-6 rounded shadow-lg w-full max-w-md relative">
            <button onclick="closeMenuEditModal()" class="absolute top-2 right-2 text-gray-500">&times;</button>
            <h2 class="text-xl font-bold mb-4">Edit Menu</h2>
            <form id="menu-edit-form">
                <input type="hidden" name="id" value="<?php echo e($selectedMenu->id ?? ''); ?>">
                <div class="mb-4">
                    <label class="block mb-1 font-semibold">Menu Name</label>
                    <input class="w-full border px-3 py-2 rounded" type="text" name="name" value="<?php echo e($selectedMenu->name ?? ''); ?>" required>
                </div>
                <div class="mb-4">
                    <label class="block mb-1 font-semibold">Location</label>
                    <input class="w-full border px-3 py-2 rounded" type="text" name="location" value="<?php echo e($selectedMenu->location ?? ''); ?>" required>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save</button>
            </form>
        </div>
    </div>

    <?php if(isset($selectedMenu) && $selectedMenu): ?>
        <!-- Add Menu Item Form -->
        <div class="mb-6 bg-white p-4 rounded shadow border border-gray-200">
            <h2 class="text-lg font-bold mb-2">Add Menu Item</h2>
            <form id="add-menu-item-form">
                <input type="hidden" name="menu_id" value="<?php echo e($selectedMenu->id); ?>">
                <div class="mb-2">
                    <label class="block mb-1 font-semibold">Title</label>
                    <input class="w-full border px-3 py-2 rounded" type="text" name="title" required>
                </div>
                <div class="mb-2">
                    <label class="block mb-1 font-semibold">Page</label>
                    <select class="w-full border px-3 py-2 rounded" name="page_id">
                        <option value="">Custom URL</option>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="block mb-1 font-semibold">Custom URL</label>
                    <input class="w-full border px-3 py-2 rounded" type="text" name="url" placeholder="/custom-link">
                </div>
                <div class="mb-2">
                    <label class="block mb-1 font-semibold">Parent</label>
                    <select class="w-full border px-3 py-2 rounded" name="parent_id">
                        <option value="">None</option>
                        <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Menu Item</button>
            </form>
        </div>

        <!-- Menu Items List -->
        <div class="bg-white p-4 rounded shadow border border-gray-200">
            <h2 class="text-lg font-bold mb-2">Menu Items</h2>
            <?php
                $tree = build_menu_tree($menuItems);
            ?>
            <?php if(count($tree)): ?>
                <ul>
                    <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('admin.menus.menu_item', ['item' => $item, 'pages' => $pages, 'menuItems' => $menuItems], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p>No menu items found.</p>
            <?php endif; ?>
        </div>

        <!-- Edit Menu Item Modal -->
        <div id="menu-item-edit-modal" class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden">
            <div class="bg-white p-6 rounded shadow-lg w-full max-w-md relative">
                <button onclick="closeMenuItemEditModal()" class="absolute top-2 right-2 text-gray-500">&times;</button>
                <h2 class="text-xl font-bold mb-4">Edit Menu Item</h2>
                <form id="menu-item-edit-form">
                    <input type="hidden" name="id" id="edit-item-id">
                    <input type="hidden" name="menu_id" value="<?php echo e($selectedMenu->id); ?>">
                    <div class="mb-2">
                        <label class="block mb-1 font-semibold">Title</label>
                        <input class="w-full border px-3 py-2 rounded" type="text" name="title" id="edit-item-title" required>
                    </div>
                    <div class="mb-2">
                        <label class="block mb-1 font-semibold">Page</label>
                        <select class="w-full border px-3 py-2 rounded" name="page_id" id="edit-item-page_id">
                            <option value="">Custom URL</option>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>"><?php echo e($p->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="block mb-1 font-semibold">Custom URL</label>
                        <input class="w-full border px-3 py-2 rounded" type="text" name="url" id="edit-item-url" placeholder="/custom-link">
                    </div>
                    <div class="mb-2">
                        <label class="block mb-1 font-semibold">Parent</label>
                        <select class="w-full border px-3 py-2 rounded" name="parent_id" id="edit-item-parent_id">
                            <option value="">None</option>
                            <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="block mb-1 font-semibold">Sort Order</label>
                        <input class="w-full border px-3 py-2 rounded" type="number" name="sort_order" id="edit-item-sort_order" min="0">
                    </div>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save</button>
                </form>
            </div>
        </div>

        <script>
        function showNotice(message) {
            const notice = document.getElementById('menu-notice');
            notice.textContent = message;
            notice.classList.remove('hidden');
            setTimeout(() => notice.classList.add('hidden'), 2000);
        }

        <?php if(isset($_GET['notice'])): ?>
            showNotice(<?php echo json_encode($_GET['notice'], 15, 512) ?>);
        <?php endif; ?>

        // Menu edit modal
        function openMenuEditModal() {
            document.getElementById('menu-edit-modal').classList.remove('hidden');
        }
        function closeMenuEditModal() {
            document.getElementById('menu-edit-modal').classList.add('hidden');
        }
        document.getElementById('menu-edit-form')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);
            const res = await fetch('/admin/menus/' + data.get('id') + '/update', {
                method: 'POST',
                body: data
            });
            if (res.ok) {
                showNotice('Menu saved successfully.');
                setTimeout(() => location.reload(), 500);
            }
        });

        // Menu create
        document.getElementById('menu-create-form')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);
            const res = await fetch('/admin/menus', {
                method: 'POST',
                body: data
            });
            if (res.ok) {
                showNotice('Menu created successfully.');
                setTimeout(() => location.reload(), 500);
            }
        });

        // Menu item add
        document.getElementById('add-menu-item-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);
            const res = await fetch('/admin/menu-items', {
                method: 'POST',
                body: data
            });
            if (res.ok) {
                showNotice('Menu item added successfully.');
                setTimeout(() => location.reload(), 500);
            }
        });

        // Menu item edit modal
        function openMenuItemEditModal(item) {
            document.getElementById('edit-item-id').value = item.id;
            document.getElementById('edit-item-title').value = item.title;
            document.getElementById('edit-item-url').value = item.url || '';
            document.getElementById('edit-item-page_id').value = item.page_id || '';
            document.getElementById('edit-item-parent_id').value = item.parent_id || '';
            document.getElementById('edit-item-sort_order').value = item.sort_order || 0;
            document.getElementById('menu-item-edit-modal').classList.remove('hidden');
        }
        function closeMenuItemEditModal() {
            document.getElementById('menu-item-edit-modal').classList.add('hidden');
        }
        document.getElementById('menu-item-edit-form')?.addEventListener('submit', async function(e) {
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);
            const res = await fetch('/admin/menu-items/' + data.get('id') + '/update', {
                method: 'POST',
                body: data
            });
            if (res.ok) {
                showNotice('Menu item saved successfully.');
                setTimeout(() => location.reload(), 500);
            }
        });

        document.querySelectorAll('.js-menu-delete, .js-menu-item-delete').forEach(form => {
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                const res = await fetch(form.action, { method: 'POST' });
                if (res.ok) {
                    showNotice('Deleted successfully.');
                    setTimeout(() => location.reload(), 500);
                }
            });
        });
        </script>
    <?php endif; ?>

    <script>
    if (!window.showNotice) {
        window.showNotice = function(message) {
            const notice = document.getElementById('menu-notice');
            if (!notice) return;
            notice.textContent = message;
            notice.classList.remove('hidden');
            setTimeout(() => notice.classList.add('hidden'), 2000);
        };
    }

    const menuCreateForm = document.getElementById('menu-create-form');
    if (menuCreateForm && !menuCreateForm.dataset.bound) {
        menuCreateForm.dataset.bound = '1';
        menuCreateForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const data = new FormData(menuCreateForm);
            const res = await fetch('/admin/menus', {
                method: 'POST',
                body: data
            });
            if (res.ok) {
                showNotice('Menu created successfully.');
                setTimeout(() => location.reload(), 500);
            }
        });
    }
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/flyCMS/views/admin/menus/index.blade.php ENDPATH**/ ?>