<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6">About This Theme</h2>
        <p class="small text-muted mb-0">Minimal Bootstrap 5 layout with hero, content, sidebar, and CTA sections.</p>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6">Navigation</h2>
        <?php echo render_menu('header'); ?>

    </div>
</div>
<?php /**PATH /shared/httpd/flyCMS/themes/bootstrap5/views/blocks/sidebar.blade.php ENDPATH**/ ?>