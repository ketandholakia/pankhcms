<nav class="menu">

<?php $__currentLoopData = ($menu ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e($item['url']); ?>">
    <?php echo e($item['title']); ?>

  </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</nav>
<?php /**PATH /shared/httpd/flyCMS/themes/flywind/views/blocks/menu.blade.php ENDPATH**/ ?>