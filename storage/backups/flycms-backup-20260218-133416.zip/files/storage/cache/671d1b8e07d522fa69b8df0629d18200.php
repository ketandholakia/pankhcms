<section class="section has-background-light py-6">
    <div class="container">
        <div class="box has-text-centered">
            <h2 class="title is-4">Need a custom website?</h2>
            <p class="mb-4">Switch themes quickly and deliver projects faster for your clients.</p>
            <a class="button is-link" href="/">Explore Site</a>
        </div>
    </div>
</section>
<?php /**PATH /shared/httpd/flyCMS/themes/bulma/views/blocks/cta.blade.php ENDPATH**/ ?>