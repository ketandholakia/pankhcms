<article class="card shadow-sm border-0 mb-3">
    <div class="card-body content-html">
        <?php echo $block['html'] ?? ''; ?>

    </div>
</article>
<?php /**PATH /shared/httpd/flyCMS/themes/bootstrap5/views/blocks/text.blade.php ENDPATH**/ ?>