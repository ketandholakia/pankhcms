<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(($page->meta_title ?? null) ?: ($page->title ?? 'flyCMS')); ?></title>
    <meta name="description" content="<?php echo e($page->meta_description ?? ''); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.2/css/bulma.min.css">
    <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/custom.css')); ?>">
    <style>
        /* Align custom menu inside Bulma navbar */
        .navbar-start,
        .navbar-end {
            align-items: center;
        }

        /* ====== MENU BASE ====== */

        .theme-menu-list {
            display: flex;
            align-items: center;
            height: 100%;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .theme-menu-item {
            position: relative;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .theme-menu-link {
            display: flex;
            align-items: center;
            height: 3.25rem; /* Bulma navbar height */
            padding: 0 0.75rem;
            font-weight: 500;
            color: #363636;
            border-radius: 6px;
        }

        .theme-menu-link:hover {
            background: #f5f5f5;
            color: #000;
        }

        /* ====== SUBMENU ====== */

        .theme-submenu {
            list-style: none;
            padding: 0.5rem 0;
            margin: 0;

            position: absolute;
            top: 100%;
            left: 0;

            min-width: 220px;

            background: #fff;
            border-radius: 10px;
            box-shadow: 0 12px 28px rgba(0,0,0,0.15);

            opacity: 0;
            visibility: hidden;
            transform: translateY(8px);
            transition: all 0.2s ease;

            z-index: 999;
        }

        .theme-submenu li a {
            display: block;
            padding: 0.6rem 1rem;
            color: #363636;
            white-space: nowrap;
        }

        .theme-submenu li a:hover {
            background: #f5f5f5;
            color: #000;
        }

        /* ====== DESKTOP HOVER ====== */

        @media (min-width: 768px) {

            .theme-menu-item:hover > .theme-submenu {
                opacity: 1;
                visibility: visible;
                transform: translateY(0);
            }

            .theme-menu-toggle {
                display: none;
            }
        }

        /* ====== MOBILE CLICK ====== */

        @media (max-width: 767px) {

            .theme-menu-list {
                flex-direction: column;
            }

            .theme-submenu {
                position: static;
                box-shadow: none;
                background: #fafafa;
                border-radius: 6px;
                margin-top: 0.25rem;
                opacity: 1;
                visibility: visible;
                transform: none;
                display: none;
            }

            .theme-menu-item.is-open > .theme-submenu {
                display: block;
            }
        }

        /* Toggle button */
        .theme-menu-toggle {
            margin-left: 6px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 0.9rem;
        }

        /* ====== CARET ICON ====== */

        .theme-menu-caret {
            margin-left: 6px;
            font-size: 0.75rem;
            opacity: 0.7;
            transition: transform 0.2s ease;
            display: inline-flex;
            align-items: center;
        }

        /* Rotate on hover (desktop) */

        @media (min-width: 768px) {
            .theme-menu-item:hover > .theme-menu-head .theme-menu-caret {
                transform: rotate(180deg);
            }
        }

        /* Rotate when open (mobile) */

        .theme-menu-item.is-open > .theme-menu-head .theme-menu-caret {
            transform: rotate(180deg);
        }
    </style>
</head>
<body>
    <nav class="navbar is-light" role="navigation" aria-label="main navigation">
        <div class="container">
            <div class="navbar-brand">
                <a class="navbar-item has-text-weight-bold" href="/">flyCMS Bulma</a>
            </div>
            <div class="navbar-menu is-active">
                <div class="navbar-start">
                </div>
                <div class="navbar-end">
                    <?php echo render_menu('header'); ?>

                    <form action="/search" method="GET" class="navbar-item" style="gap:8px;display:flex;">
                        <input type="text" name="q" placeholder="Search..." class="input" required>
                        <button class="button is-dark" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="footer py-5">
        <div class="content has-text-centered">
            <p>Powered by flyCMS Theme System</p>
        </div>
    </footer>

    <script>
        document.addEventListener('click', function (event) {
            const toggle = event.target.closest('.theme-menu-toggle');
            const openItems = document.querySelectorAll('.theme-menu-item.is-open');

            if (!toggle) {
                openItems.forEach(function (item) {
                    item.classList.remove('is-open');
                    const btn = item.querySelector('.theme-menu-toggle');
                    if (btn) btn.setAttribute('aria-expanded', 'false');
                });
                return;
            }

            const item = toggle.closest('.theme-menu-item');
            const willOpen = !item.classList.contains('is-open');

            openItems.forEach(function (openItem) {
                openItem.classList.remove('is-open');
                const btn = openItem.querySelector('.theme-menu-toggle');
                if (btn) btn.setAttribute('aria-expanded', 'false');
            });

            if (willOpen) {
                item.classList.add('is-open');
                toggle.setAttribute('aria-expanded', 'true');
            }
        });
    </script>
</body>
</html>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/bulma/views/layouts/site.blade.php ENDPATH**/ ?>