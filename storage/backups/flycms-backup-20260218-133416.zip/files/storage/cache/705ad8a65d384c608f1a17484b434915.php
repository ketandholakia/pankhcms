<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
  <title><?php echo e(($page->meta_title ?? null) ?: ($title ?? ($site_title ?? ($seo_default_title ?? 'flyCMS')))); ?></title>
  <meta name="description" content="<?php echo e(($page->meta_description ?? null) ?: ($seo_default_description ?? '')); ?>">
  <meta name="keywords" content="<?php echo e(($page->meta_keywords ?? null) ?: ($seo_default_keywords ?? '')); ?>">

  
  <meta property="og:title" content="<?php echo e(($page->og_title ?? null) ?: ($og_title_default ?? ($seo_default_title ?? $site_title ?? 'flyCMS'))); ?>">
  <meta property="og:description" content="<?php echo e(($page->og_description ?? null) ?: ($og_description_default ?? ($seo_default_description ?? $site_description ?? ''))); ?>">
  <meta property="og:image" content="<?php echo e(($page->og_image ?? null) ?: ($og_image_default ?? '')); ?>">
  <meta property="og:url" content="<?php echo e(($page->canonical_url ?? null) ?: ($canonical_base ?? env('APP_URL') . \Flight::request()->url)); ?>">
  <meta property="og:type" content="website">

  
  <link rel="canonical" href="<?php echo e(($page->canonical_url ?? null) ?: ($canonical_base ?? env('APP_URL') . \Flight::request()->url)); ?>">

  
  <meta name="robots" content="<?php echo e(($page->robots ?? null) ?: ($robots_default ?? 'index, follow')); ?>">

  
  <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/flywind-core.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/custom.css')); ?>">
  <meta name="twitter:card" content="<?php echo e(($page->twitter_card ?? null) ?: ($twitter_card ?? 'summary_large_image')); ?>">
  <meta name="twitter:site" content="<?php echo e(($page->twitter_site ?? null) ?: ($twitter_site ?? '')); ?>">
  <meta name="twitter:title" content="<?php echo e(($page->og_title ?? null) ?: ($og_title_default ?? ($seo_default_title ?? $site_title ?? 'flyCMS'))); ?>">
  <meta name="twitter:description" content="<?php echo e(($page->og_description ?? null) ?: ($og_description_default ?? ($seo_default_description ?? $site_description ?? ''))); ?>">
  <meta name="twitter:image" content="<?php echo e(($page->og_image ?? null) ?: ($og_image_default ?? '')); ?>">

  
  <?php if(setting('breadcrumbs_enabled') === '1' && !empty($breadcrumbs)): ?>
      <nav class="breadcrumb container" aria-label="breadcrumbs">
          <ul>
              <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['is-active' => $loop->last]); ?>">
                      <?php if(!$loop->last): ?>
                          <a href="<?php echo e($crumb['url']); ?>"><?php echo e($crumb['title']); ?></a>
                      <?php else: ?>
                          <span><?php echo e($crumb['title']); ?></span>
                      <?php endif; ?>
                  </li>
                  <?php if(!$loop->last): ?>
                      <span class="breadcrumb-separator"><?php echo e(setting('breadcrumbs_separator', '/')); ?></span>
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </nav>
      <?php if(setting('breadcrumbs_schema') === '1'): ?>
          <?php echo breadcrumbSchema($breadcrumbs); ?>

      <?php endif; ?>
  <?php endif; ?>


  <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/flywind-core.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(\App\Core\Theme::asset('css/custom.css')); ?>">
  <style>
        .breadcrumb { margin-top: 1rem; margin-bottom: 1rem; }
        .breadcrumb ul { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; align-items: center; }
        .breadcrumb li { display: flex; align-items: center; }
        .breadcrumb li a { text-decoration: none; color: var(--primary); }
        .breadcrumb li.is-active span { color: var(--muted); }
        .breadcrumb-separator { margin: 0 0.5rem; color: var(--muted); }
  </style>
</head>

<body>

<header class="site-header">
  <div class="container nav">

    <strong><?php echo e($site_title ?? 'flyCMS'); ?></strong>

    <?php echo $__env->make('blocks.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  </div>
</header>


<?php if(isset($hero)): ?>
  <?php echo $__env->make('blocks.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>

<main class="container layout mt-2">

  <section>
    <?php echo $__env->yieldContent('content'); ?>
  </section>

  <?php echo $__env->make('blocks.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</main>

<footer class="site-footer">
  <div class="container">
    © <?php echo e(date('Y')); ?> <?php echo e($site_title ?? 'flyCMS'); ?>

  </div>
</footer>

</body>
</html>
<?php /**PATH /shared/httpd/flyCMS/themes/flywind/views/layouts/site.blade.php ENDPATH**/ ?>