<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="text-2xl font-bold mb-4">Categories</h1>

    <div id="category-notice" class="fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded shadow hidden">
        Saved successfully.
    </div>

    <button onclick="openAddModal()" class="mb-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Category</button>

    <!-- Add/Edit Modal -->
    <div id="category-modal" class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden">
        <div class="bg-white p-6 rounded shadow-lg w-full max-w-md relative">
            <button onclick="closeModal()" class="absolute top-2 right-2 text-gray-500">&times;</button>
            <h2 id="modal-title" class="text-xl font-bold mb-4">Add Category</h2>
            <form id="category-form">
                <input type="hidden" id="category-id" name="id">
                <div class="mb-4">
                    <label class="block mb-1 font-semibold" for="modal-name">Category Name</label>
                    <input class="w-full border px-3 py-2 rounded" type="text" id="modal-name" name="name" required>
                </div>
                <div class="mb-4">
                    <label class="block mb-1 font-semibold" for="modal-slug">Slug</label>
                    <input class="w-full border px-3 py-2 rounded" type="text" id="modal-slug" name="slug" required>
                </div>
                <div class="mb-4">
                    <label class="block mb-1 font-semibold" for="modal-parent">Parent Category</label>
                    <select class="w-full border px-3 py-2 rounded" id="modal-parent" name="parent_id">
                        <option value="">None</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save</button>
            </form>
        </div>
    </div>

    <script>
    function openAddModal() {
        document.getElementById('modal-title').innerText = 'Add Category';
        document.getElementById('category-id').value = '';
        document.getElementById('modal-name').value = '';
        document.getElementById('modal-slug').value = '';
        document.getElementById('modal-parent').value = '';
        document.getElementById('category-modal').classList.remove('hidden');
    }
    function openEditModal(id, name, slug, parent_id) {
        document.getElementById('modal-title').innerText = 'Edit Category';
        document.getElementById('category-id').value = id;
        document.getElementById('modal-name').value = name;
        document.getElementById('modal-slug').value = slug;
        document.getElementById('modal-parent').value = parent_id || '';
        document.getElementById('category-modal').classList.remove('hidden');
    }
    function closeModal() {
        document.getElementById('category-modal').classList.add('hidden');
    }
    function showNotice() {
        const notice = document.getElementById('category-notice');
        notice.classList.remove('hidden');
        setTimeout(() => notice.classList.add('hidden'), 2000);
    }
    document.getElementById('category-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        const id = document.getElementById('category-id').value;
        const name = document.getElementById('modal-name').value;
        const slug = document.getElementById('modal-slug').value;
        const parent_id = document.getElementById('modal-parent').value;
        const data = new FormData();
        data.append('name', name);
        data.append('slug', slug);
        if (parent_id) data.append('parent_id', parent_id);
        let url = '/admin/categories';
        let method = 'POST';
        if (id) {
            url = `/admin/categories/${id}/update`;
        }
        const res = await fetch(url, { method, body: data });
        if (res.ok) {
            closeModal();
            showNotice();
            setTimeout(() => location.reload(), 500);
        }
    });
    async function deleteCategory(id) {
        if (!confirm('Delete this category?')) return;
        const res = await fetch(`/admin/categories/${id}/delete`, { method: 'POST' });
        if (res.ok) location.reload();
    }
    </script>

    <?php if(isset($categories) && count($categories)): ?>
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">ID</th>
                    <th class="py-2 px-4 border-b">Name</th>
                    <th class="py-2 px-4 border-b">Slug</th>
                    <th class="py-2 px-4 border-b">Parent</th>
                    <th class="py-2 px-4 border-b">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-2 px-4 border-b"><?php echo e($cat->id); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($cat->name); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($cat->slug); ?></td>
                        <td class="py-2 px-4 border-b">
                            <?php
                                $parent = $categories->firstWhere('id', $cat->parent_id);
                            ?>
                            <?php echo e($parent ? $parent->name : ''); ?>

                        </td>
                        <td class="py-2 px-4 border-b">
                            <button onclick="openEditModal('<?php echo e($cat->id); ?>', '<?php echo e(addslashes($cat->name)); ?>', '<?php echo e(addslashes($cat->slug)); ?>', '<?php echo e($cat->parent_id); ?>')" class="bg-yellow-400 text-white px-2 py-1 rounded mr-2">Edit</button>
                            <button onclick="deleteCategory('<?php echo e($cat->id); ?>')" class="bg-red-600 text-white px-2 py-1 rounded">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No categories found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /shared/httpd/flyCMS/views/admin/categories/index.blade.php ENDPATH**/ ?>