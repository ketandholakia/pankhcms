<li>
    <div class="flex items-center mb-1">
        <span class="font-semibold"><?php echo e($item->title); ?></span>
        <span class="ml-2 text-gray-500 text-xs">
            <?php if($item->page_id): ?>
                (Page)
            <?php elseif($item->url): ?>
                (<?php echo e($item->url); ?>)
            <?php endif; ?>
        </span>
        <button onclick="openMenuItemEditModal({
            id: <?php echo e($item->id); ?>,
            title: <?php echo json_encode($item->title, 15, 512) ?>,
            url: <?php echo json_encode($item->url, 15, 512) ?>,
            page_id: <?php echo json_encode($item->page_id, 15, 512) ?>,
            parent_id: <?php echo json_encode($item->parent_id, 15, 512) ?>,
            sort_order: <?php echo json_encode($item->sort_order, 15, 512) ?>
        })" class="bg-yellow-400 text-white px-2 py-1 rounded text-xs ml-2">Edit</button>
        <form action="/admin/menu-items/<?php echo e($item->id); ?>/delete" method="POST" class="inline ml-2 js-menu-item-delete" onsubmit="return confirm('Delete this menu item?');">
            <button type="submit" class="bg-red-600 text-white px-2 py-1 rounded text-xs">Delete</button>
        </form>
        <form action="/admin/menu-items/<?php echo e($item->id); ?>/move" method="POST" class="inline ml-1">
            <input type="hidden" name="direction" value="up">
            <button type="submit" class="bg-gray-300 text-xs px-2 py-1 rounded">&#8593;</button>
        </form>
        <form action="/admin/menu-items/<?php echo e($item->id); ?>/move" method="POST" class="inline ml-1">
            <input type="hidden" name="direction" value="down">
            <button type="submit" class="bg-gray-300 text-xs px-2 py-1 rounded">&#8595;</button>
        </form>
    </div>
    <?php if(!empty($item->children)): ?>
        <ul class="ml-6">
            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.menus.menu_item', ['item' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH /shared/httpd/flyCMS/views/admin/menus/menu_item.blade.php ENDPATH**/ ?>