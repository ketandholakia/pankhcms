<article class="box content">
    <?php echo $block['html'] ?? ''; ?>

</article>
<?php /**PATH /shared/httpd/flyCMS/themes/bulma/views/blocks/text.blade.php ENDPATH**/ ?>