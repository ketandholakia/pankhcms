<section class="hero is-primary is-small">
    <div class="hero-body">
        <div class="container">
            <h1 class="title"><?php echo e($page->title ?? 'Welcome'); ?></h1>
            <?php if(!empty($page->meta_description)): ?>
                <p class="subtitle"><?php echo e($page->meta_description); ?></p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /shared/httpd/flyCMS/themes/bulma/views/blocks/hero.blade.php ENDPATH**/ ?>