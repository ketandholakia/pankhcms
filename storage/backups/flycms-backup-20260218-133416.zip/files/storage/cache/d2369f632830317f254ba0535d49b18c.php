<section class="hero">
  <div class="container">

    <h1><?php echo e($hero['title'] ?? $site_title ?? 'flyCMS'); ?></h1>

    <?php if(!empty($hero['subtitle'])): ?>
      <p><?php echo e($hero['subtitle']); ?></p>
    <?php endif; ?>

  </div>
</section>
<?php /**PATH /home/vi/devilbox/data/www/flyCMS/themes/flywind/views/blocks/hero.blade.php ENDPATH**/ ?>